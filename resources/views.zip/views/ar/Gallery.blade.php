@extends('ar.layout')
@section('content')



<!DOCTYPE html>
<!-- saved from url=(0046)http://watrax.com/2020/opfor/july/ali/explore/ -->
<html lang="en-US" class="js supports no-touchevents no-forcetouch cssanimations no-cssgridlegacy cssgrid cssfilters csstransforms csstransforms3d csstransitions mobile-false not-iOS" style="">
<!--<![endif]-->

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
	<meta name="theme-color" content="#ffe0e0">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="stylesheet" href="	https://7basis.com/wp-content/themes/dt-the7/fonts/icomoon-the7-font/icomoon-the7-font.css">

	<script id="facebook-jssdk" src="/Explore – Nooneen Design_files/xfbml.customerchat.js"></script>
	<script type="text/javascript">
		if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
			var originalAddEventListener = EventTarget.prototype.addEventListener,
				oldWidth = window.innerWidth;

			EventTarget.prototype.addEventListener = function(eventName, eventHandler, useCapture) {
				if (eventName === "resize") {
					originalAddEventListener.call(this, eventName, function(event) {
						if (oldWidth === window.innerWidth) {
							return;
						} else if (oldWidth !== window.innerWidth) {
							oldWidth = window.innerWidth;
						}
						if (eventHandler.handleEvent) {
							eventHandler.handleEvent.call(this, event);
						} else {
							eventHandler.call(this, event);
						};
					}, useCapture);
				} else {
					originalAddEventListener.call(this, eventName, eventHandler, useCapture);
				};
			};
		};
	</script>
	<title>Explore – Nooneen Design</title>
	<link rel="stylesheet" href="	https://7basis.com/wp-content/themes/dt-the7/fonts/icomoon-the7-font/icomoon-the7-font.css">

	<link href="/fontawesome-free-5.15.1-web/css/all.min.css" rel="stylesheet">
	<!--load all styles -->

	<meta name="robots" content="noindex,nofollow">
	<link rel="alternate" hreflang="en" href="http://watrax.com/2020/opfor/july/ali/explore/">
	<link rel="dns-prefetch" href="http://cdnjs.cloudflare.com/">
	<link rel="dns-prefetch" href="http://kit-pro.fontawesome.com/">
	<link rel="dns-prefetch" href="http://fonts.googleapis.com/">
	<link rel="dns-prefetch" href="http://s.w.org/">
	<link rel="alternate" type="application/rss+xml" title="Nooneen Design » Feed" href="http://watrax.com/2020/opfor/july/ali/feed/">
	<link rel="alternate" type="application/rss+xml" title="Nooneen Design » Comments Feed" href="http://watrax.com/2020/opfor/july/ali/comments/feed/">
	<script type="text/javascript">
		window._wpemojiSettings = {
			"baseUrl": "https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/",
			"ext": ".png",
			"svgUrl": "https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/",
			"svgExt": ".svg",
			"source": {
				"concatemoji": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.4.4"
			}
		};
		/*! This file is auto-generated */
		! function(e, a, t) {
			var r, n, o, i, p = a.createElement("canvas"),
				s = p.getContext && p.getContext("2d");

			function c(e, t) {
				var a = String.fromCharCode;
				s.clearRect(0, 0, p.width, p.height), s.fillText(a.apply(this, e), 0, 0);
				var r = p.toDataURL();
				return s.clearRect(0, 0, p.width, p.height), s.fillText(a.apply(this, t), 0, 0), r === p.toDataURL()
			}

			function l(e) {
				if (!s || !s.fillText) return !1;
				switch (s.textBaseline = "top", s.font = "600 32px Arial", e) {
					case "flag":
						return !c([127987, 65039, 8205, 9895, 65039], [127987, 65039, 8203, 9895, 65039]) && (!c([55356, 56826, 55356, 56819], [55356, 56826, 8203, 55356, 56819]) && !c([55356, 57332, 56128, 56423, 56128, 56418, 56128, 56421, 56128, 56430, 56128,
							56423, 56128, 56447
						], [55356, 57332, 8203, 56128, 56423, 8203, 56128, 56418, 8203, 56128, 56421, 8203, 56128, 56430, 8203, 56128, 56423, 8203, 56128, 56447]));
					case "emoji":
						return !c([55357, 56424, 55356, 57342, 8205, 55358, 56605, 8205, 55357, 56424, 55356, 57340], [55357, 56424, 55356, 57342, 8203, 55358, 56605, 8203, 55357, 56424, 55356, 57340])
				}
				return !1
			}

			function d(e) {
				var t = a.createElement("script");
				t.src = e, t.defer = t.type = "text/javascript", a.getElementsByTagName("head")[0].appendChild(t)
			}
			for (i = Array("flag", "emoji"), t.supports = {
					everything: !0,
					everythingExceptFlag: !0
				}, o = 0; o < i.length; o++) t.supports[i[o]] = l(i[o]), t.supports.everything = t.supports.everything && t.supports[i[o]], "flag" !== i[o] && (t.supports.everythingExceptFlag = t.supports.everythingExceptFlag && t.supports[i[o]]);
			t.supports.everythingExceptFlag = t.supports.everythingExceptFlag && !t.supports.flag, t.DOMReady = !1, t.readyCallback = function() {
				t.DOMReady = !0
			}, t.supports.everything || (n = function() {
				t.readyCallback()
			}, a.addEventListener ? (a.addEventListener("DOMContentLoaded", n, !1), e.addEventListener("load", n, !1)) : (e.attachEvent("onload", n), a.attachEvent("onreadystatechange", function() {
				"complete" === a.readyState && t.readyCallback()
			})), (r = t.source || {}).concatemoji ? d(r.concatemoji) : r.wpemoji && r.twemoji && (d(r.twemoji), d(r.wpemoji)))
		}(window, document, window._wpemojiSettings);
	</script>
	<script src="/Explore – Nooneen Design_files/wp-emoji-release.min.js" type="text/javascript" defer=""></script>
	<style type="text/css">
		img.wp-smiley,
		img.emoji {
			display: inline !important;
			border: none !important;
			box-shadow: none !important;
			height: 1em !important;
			width: 1em !important;
			margin: 0 .07em !important;
			vertical-align: -0.1em !important;
			background: none !important;
			padding: 0 !important;
		}
	</style>
	<link rel="stylesheet" id="wp-block-library-css" href="/Explore – Nooneen Design_files/style.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="wp-block-library-theme-css" href="/Explore – Nooneen Design_files/theme.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="wc-block-vendors-style-css" href="/Explore – Nooneen Design_files/vendors-style.css" type="text/css" media="all">
	<link rel="stylesheet" id="wc-block-style-css" href="/Explore – Nooneen Design_files/style.css" type="text/css" media="all">
	<link rel="stylesheet" id="contact-form-7-css" href="/Explore – Nooneen Design_files/styles.css" type="text/css" media="all">
	<link rel="stylesheet" id="dq-fontawesome-css" href="/Explore – Nooneen Design_files/pro.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="dq-slick-css-css" href="/Explore – Nooneen Design_files/slick.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="dq-slick-theme-css-css" href="/Explore – Nooneen Design_files/slick-theme.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="dq-style-css" href="/Explore – Nooneen Design_files/style(1).css" type="text/css" media="all">
	<link rel="stylesheet" id="dq-responsive-style-css" href="/Explore – Nooneen Design_files/responsive.css" type="text/css" media="all">
	<link rel="stylesheet" id="pafe-extension-style-css" href="/Explore – Nooneen Design_files/extension.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="pafe-woocommerce-sales-funnels-style-css" href="/Explore – Nooneen Design_files/woocommerce-sales-funnels.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="rs-plugin-settings-css" href="/Explore – Nooneen Design_files/rs6.css" type="text/css" media="all">
	<style id="rs-plugin-settings-inline-css" type="text/css">
		#rs-demo-id {}
	</style>
	<style id="woocommerce-inline-inline-css" type="text/css">
		.woocommerce form .form-row .required {
			visibility: visible;
		}
	</style>
	<link rel="stylesheet" id="wpml-legacy-horizontal-list-0-css" href="/Explore – Nooneen Design_files/style(2).css" type="text/css" media="all">
	<link rel="stylesheet" id="wpml-menu-item-0-css" href="/Explore – Nooneen Design_files/style(3).css" type="text/css" media="all">
	<link rel="stylesheet" id="elementor-icons-css" href="/Explore – Nooneen Design_files/elementor-icons.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="elementor-animations-css" href="/Explore – Nooneen Design_files/animations.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="elementor-frontend-css" href="/Explore – Nooneen Design_files/frontend.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="elementor-pro-css" href="/Explore – Nooneen Design_files/frontend.min(1).css" type="text/css" media="all">
	<link rel="stylesheet" id="premium-pro-css" href="/Explore – Nooneen Design_files/premium-addons.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="elementor-global-css" href="/Explore – Nooneen Design_files/global.css" type="text/css" media="all">
	<link rel="stylesheet" id="elementor-post-224-css" href="/Explore – Nooneen Design_files/post-224.css" type="text/css" media="all">
	<link rel="stylesheet" id="elementor-post-573-css" href="/Explore – Nooneen Design_files/post-573.css" type="text/css" media="all">
	<link rel="stylesheet" id="elementor-post-559-css" href="/Explore – Nooneen Design_files/post-559.css" type="text/css" media="all">
	<link rel="stylesheet" id="elementor-post-616-css" href="/Explore – Nooneen Design_files/post-616.css" type="text/css" media="all">
	<link rel="stylesheet" id="elementor-post-120-css" href="/Explore – Nooneen Design_files/post-120.css" type="text/css" media="all">
	<link rel="stylesheet" id="dt-web-fonts-css" href="/Explore – Nooneen Design_files/css" type="text/css" media="all">
	<link rel="stylesheet" id="dt-main-css" href="/Explore – Nooneen Design_files/main.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="the7-font-css" href="/Explore – Nooneen Design_files/icomoon-the7-font.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="the7-core-css" href="/Explore – Nooneen Design_files/post-type.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="dt-custom-css" href="/Explore – Nooneen Design_files/custom.css" type="text/css" media="all">
	<link rel="stylesheet" id="wc-dt-custom-css" href="/Explore – Nooneen Design_files/wc-dt-custom.css" type="text/css" media="all">
	<link rel="stylesheet" id="dt-media-css" href="/Explore – Nooneen Design_files/media.css" type="text/css" media="all">
	<link rel="stylesheet" id="the7-mega-menu-css" href="/Explore – Nooneen Design_files/mega-menu.css" type="text/css" media="all">
	<link rel="stylesheet" id="the7-elements-css" href="/Explore – Nooneen Design_files/post-type-dynamic.css" type="text/css" media="all">
	<link rel="stylesheet" id="style-css" href="/Explore – Nooneen Design_files/style(4).css" type="text/css" media="all">
	<link rel="stylesheet" id="the7-elementor-global-css" href="/Explore – Nooneen Design_files/elementor-global.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="ecs-styles-css" href="/Explore – Nooneen Design_files/ecs-style.css" type="text/css" media="all">
	<link rel="stylesheet" id="google-fonts-1-css" href="/Explore – Nooneen Design_files/css(1)" type="text/css" media="all">
	<link rel="stylesheet" id="elementor-icons-shared-0-css" href="/Explore – Nooneen Design_files/fontawesome.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="elementor-icons-fa-solid-css" href="/Explore – Nooneen Design_files/solid.min.css" type="text/css" media="all">
	<script type="text/javascript">
		/* <![CDATA[ */
		var papro_addons = {
			"url": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-admin\/admin-ajax.php",
			"particles_url": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/plugins\/premium-addons-pro\/assets\/frontend\/min-js\/particles.min.js",
			"kenburns_url": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/plugins\/premium-addons-pro\/assets\/frontend\/min-js\/cycle.min.js",
			"gradient_url": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/plugins\/premium-addons-pro\/assets\/frontend\/min-js\/premium-gradient.min.js",
			"parallax_url": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/plugins\/premium-addons-pro\/assets\/frontend\/min-js\/premium-parallax.min.js"
		};
		/* ]]> */
	</script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/jquery.js"></script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/jquery-migrate.min.js"></script>
	<script type="text/javascript">
		window.scopes_array = [];
		window.backend = 0;
		jQuery(window).on("elementor/frontend/init", function() {
			elementorFrontend.hooks.addAction("frontend/element_ready/section", function($scope, $) {
				if ("undefined" == typeof $scope) {
					return;
				}
				if ($scope.hasClass("premium-parallax-yes")) {
					window.scopes_array.push($scope);
				}
				if (elementorFrontend.isEditMode()) {
					var url = papro_addons.parallax_url;
					jQuery.cachedAssets = function(url, options) {
						// Allow user to set any option except for dataType, cache, and url.
						options = jQuery.extend(options || {}, {
							dataType: "script",
							cache: true,
							url: url
						});
						// Return the jqXHR object so we can chain callbacks.
						return jQuery.ajax(options);
					};
					jQuery.cachedAssets(url);
					window.backend = 1;
				}
			});
		});
		jQuery(document).ready(function() {
			if (jQuery.find(".premium-parallax-yes").length < 1) {
				return;
			}

			var url = papro_addons.parallax_url;

			jQuery.cachedAssets = function(url, options) {
				// Allow user to set any option except for dataType, cache, and url.
				options = jQuery.extend(options || {}, {
					dataType: "script",
					cache: true,
					url: url
				});

				// Return the jqXHR object so we can chain callbacks.
				return jQuery.ajax(options);
			};
			jQuery.cachedAssets(url);
		});
		window.scopes_array = [];
		window.backend = 0;
		jQuery(window).on("elementor/frontend/init", function() {
			elementorFrontend.hooks.addAction("frontend/element_ready/section", function($scope, $) {
				if ("undefined" == typeof $scope) {
					return;
				}
				if ($scope.hasClass("premium-particles-yes")) {
					window.scopes_array.push($scope);
				}
				if (elementorFrontend.isEditMode()) {
					var url = papro_addons.particles_url;
					jQuery.cachedAssets = function(url, options) {
						// Allow user to set any option except for dataType, cache, and url.
						options = jQuery.extend(options || {}, {
							dataType: "script",
							cache: true,
							url: url
						});
						// Return the jqXHR object so we can chain callbacks.
						return jQuery.ajax(options);
					};
					jQuery.cachedAssets(url);
					window.backend = 1;
				}
			});
		});
		jQuery(document).ready(function() {
			if (jQuery.find(".premium-particles-yes").length < 1) {

				return;
			}
			var url = papro_addons.particles_url;

			jQuery.cachedAssets = function(url, options) {
				// Allow user to set any option except for dataType, cache, and url.
				options = jQuery.extend(options || {}, {
					dataType: "script",
					cache: true,
					url: url
				});

				// Return the jqXHR object so we can chain callbacks.
				return jQuery.ajax(options);
			};
			jQuery.cachedAssets(url);
		});
		window.scopes_array = [];
		window.backend = 0;
		jQuery(window).on("elementor/frontend/init", function() {
			elementorFrontend.hooks.addAction("frontend/element_ready/section", function($scope, $) {
				if ("undefined" == typeof $scope) {
					return;
				}
				if ($scope.hasClass("premium-gradient-yes")) {
					window.scopes_array.push($scope);
				}
				if (elementorFrontend.isEditMode()) {
					var url = papro_addons.gradient_url;
					jQuery.cachedAssets = function(url, options) {
						// Allow user to set any option except for dataType, cache, and url.
						options = jQuery.extend(options || {}, {
							dataType: "script",
							cache: true,
							url: url
						});
						// Return the jqXHR object so we can chain callbacks.
						return jQuery.ajax(options);
					};
					jQuery.cachedAssets(url);
					window.backend = 1;
				}
			});
		});
		jQuery(document).ready(function() {
			if (jQuery.find(".premium-gradient-yes").length < 1) {
				return;
			}

			var url = papro_addons.gradient_url;

			jQuery.cachedAssets = function(url, options) {
				// Allow user to set any option except for dataType, cache, and url.
				options = jQuery.extend(options || {}, {
					dataType: "script",
					cache: true,
					url: url
				});

				// Return the jqXHR object so we can chain callbacks.
				return jQuery.ajax(options);
			};
			jQuery.cachedAssets(url);
		});
		window.scopes_array = [];
		window.backend = 0;
		jQuery(window).on("elementor/frontend/init", function() {
			elementorFrontend.hooks.addAction("frontend/element_ready/section", function($scope, $) {
				if ("undefined" == typeof $scope) {
					return;
				}
				if ($scope.hasClass("premium-kenburns-yes")) {
					window.scopes_array.push($scope);
				}
			});
		});
		jQuery(document).ready(function() {
			if (jQuery.find(".premium-kenburns-yes").length < 1) {
				return;
			}

			var url = papro_addons.kenburns_url;

			jQuery.cachedAssets = function(url, options) {
				// Allow user to set any option except for dataType, cache, and url.
				options = jQuery.extend(options || {}, {
					dataType: "script",
					cache: true,
					url: url
				});

				// Return the jqXHR object so we can chain callbacks.
				return jQuery.ajax(options);
			};
			jQuery.cachedAssets(url);
		});
	</script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/jquery.cookie.js"></script>
	<script type="text/javascript">
		/* <![CDATA[ */
		var wpml_cookies = {
			"wp-wpml_current_language": {
				"value": "en",
				"expires": 1,
				"path": "\/"
			}
		};
		var wpml_cookies = {
			"wp-wpml_current_language": {
				"value": "en",
				"expires": 1,
				"path": "\/"
			}
		};
		/* ]]> */
	</script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/language-cookie.js"></script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/slick.min.js"></script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/scripts.js"></script>
	<script type="text/javascript">
		/* <![CDATA[ */
		var ajax_object = {
			"ajaxurl": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-admin\/admin-ajax.php"
		};
		var plugin_dir_url = ["http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/plugins\/design_quiz\/"];
		/* ]]> */
	</script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/ajax.js"></script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/extension.min.js"></script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/woocommerce-sales-funnels.min.js"></script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/rbtools.min.js"></script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/rs6.min.js"></script>
	<script type="text/javascript">
		/* <![CDATA[ */
		var dtLocal = {
			"themeUrl": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/themes\/techreshape_v4.3",
			"passText": "To view this protected post, enter the password below:",
			"moreButtonText": {
				"loading": "Loading...",
				"loadMore": "Load more"
			},
			"postID": "224",
			"ajaxurl": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-admin\/admin-ajax.php",
			"REST": {
				"baseUrl": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-json\/the7\/v1",
				"endpoints": {
					"sendMail": "\/send-mail"
				}
			},
			"contactMessages": {
				"required": "One or more fields have an error. Please check and try again.",
				"terms": "Please accept the privacy policy.",
				"fillTheCaptchaError": "Please, fill the captcha."
			},
			"captchaSiteKey": "",
			"ajaxNonce": "ab6fb5a2dd",
			"pageData": {
				"type": "page",
				"template": "page",
				"layout": null
			},
			"themeSettings": {
				"smoothScroll": "off",
				"lazyLoading": false,
				"accentColor": {
					"mode": "solid",
					"color": "#ffe0e0"
				},
				"desktopHeader": {
					"height": 90
				},
				"ToggleCaptionEnabled": "disabled",
				"ToggleCaption": "Navigation",
				"floatingHeader": {
					"showAfter": 94,
					"showMenu": true,
					"height": 60,
					"logo": {
						"showLogo": true,
						"html": "<img class=\" preload-me\" src=\"http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/uploads\/2020\/10\/float-1.png\" srcset=\"http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/uploads\/2020\/10\/float-1.png 103w, http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/uploads\/2020\/10\/floationg-logo.png 103w\" width=\"103\" height=\"50\"   sizes=\"103px\" alt=\"Nooneen Design\" \/>",
						"url": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/"
					}
				},
				"topLine": {
					"floatingTopLine": {
						"logo": {
							"showLogo": false,
							"html": ""
						}
					}
				},
				"mobileHeader": {
					"firstSwitchPoint": 992,
					"secondSwitchPoint": 778,
					"firstSwitchPointHeight": 60,
					"secondSwitchPointHeight": 60,
					"mobileToggleCaptionEnabled": "disabled",
					"mobileToggleCaption": "Menu"
				},
				"stickyMobileHeaderFirstSwitch": {
					"logo": {
						"html": "<img class=\" preload-me\" src=\"http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/uploads\/2020\/10\/Mobile-Logo.png\" srcset=\"http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/uploads\/2020\/10\/Mobile-Logo.png 72w\" width=\"72\" height=\"35\"   sizes=\"72px\" alt=\"Nooneen Design\" \/>"
					}
				},
				"stickyMobileHeaderSecondSwitch": {
					"logo": {
						"html": "<img class=\" preload-me\" src=\"http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/uploads\/2020\/10\/Mobile-Logo.png\" srcset=\"http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/uploads\/2020\/10\/Mobile-Logo.png 72w\" width=\"72\" height=\"35\"   sizes=\"72px\" alt=\"Nooneen Design\" \/>"
					}
				},
				"content": {
					"textColor": "#8b8d94",
					"headerColor": "#333333"
				},
				"sidebar": {
					"switchPoint": 992
				},
				"boxedWidth": "1280px",
				"stripes": {
					"stripe1": {
						"textColor": "#787d85",
						"headerColor": "#3b3f4a"
					},
					"stripe2": {
						"textColor": "#8b9199",
						"headerColor": "#ffffff"
					},
					"stripe3": {
						"textColor": "#ffffff",
						"headerColor": "#ffffff"
					}
				}
			},
			"wcCartFragmentHash": "e512a72c2c4de1aaeef02992ceb65a2d",
			"elementor": {
				"settings": {
					"container_width": 0
				}
			}
		};
		var dtShare = {
			"shareButtonText": {
				"facebook": "Share on Facebook",
				"twitter": "Tweet",
				"pinterest": "Pin it",
				"linkedin": "Share on Linkedin",
				"whatsapp": "Share on Whatsapp"
			},
			"overlayOpacity": "85"
		};
		/* ]]> */
	</script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/above-the-fold.min.js"></script>
	<script type="text/javascript">
		/* <![CDATA[ */
		var ecs_ajax_params = {
			"ajaxurl": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-admin\/admin-ajax.php",
			"posts": "{\"page\":0,\"pagename\":\"explore\",\"error\":\"\",\"m\":\"\",\"p\":0,\"post_parent\":\"\",\"subpost\":\"\",\"subpost_id\":\"\",\"attachment\":\"\",\"attachment_id\":0,\"name\":\"explore\",\"page_id\":0,\"second\":\"\",\"minute\":\"\",\"hour\":\"\",\"day\":0,\"monthnum\":0,\"year\":0,\"w\":0,\"category_name\":\"\",\"tag\":\"\",\"cat\":\"\",\"tag_id\":\"\",\"author\":\"\",\"author_name\":\"\",\"feed\":\"\",\"tb\":\"\",\"paged\":0,\"meta_key\":\"\",\"meta_value\":\"\",\"preview\":\"\",\"s\":\"\",\"sentence\":\"\",\"title\":\"\",\"fields\":\"\",\"menu_order\":\"\",\"embed\":\"\",\"category__in\":[],\"category__not_in\":[],\"category__and\":[],\"post__in\":[],\"post__not_in\":[],\"post_name__in\":[],\"tag__in\":[],\"tag__not_in\":[],\"tag__and\":[],\"tag_slug__in\":[],\"tag_slug__and\":[],\"post_parent__in\":[],\"post_parent__not_in\":[],\"author__in\":[],\"author__not_in\":[],\"ignore_sticky_posts\":false,\"suppress_filters\":false,\"cache_results\":true,\"update_post_term_cache\":true,\"lazy_load_term_meta\":true,\"update_post_meta_cache\":true,\"post_type\":\"\",\"posts_per_page\":10,\"nopaging\":false,\"comments_per_page\":\"50\",\"no_found_rows\":false,\"order\":\"DESC\"}"
		};
		/* ]]> */
	</script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/ecs_ajax_pagination.js"></script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/ecs.js"></script>
	<link rel="https://api.w.org/" href="http://watrax.com/2020/opfor/july/ali/wp-json/">
	<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://watrax.com/2020/opfor/july/ali/xmlrpc.php?rsd">
	<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://watrax.com/2020/opfor/july/ali/wp-includes/wlwmanifest.xml">
	<meta name="generator" content="WordPress 5.4.4">
	<meta name="generator" content="WooCommerce 4.3.1">
	<link rel="canonical" href="http://watrax.com/2020/opfor/july/ali/explore/">
	<link rel="shortlink" href="http://watrax.com/2020/opfor/july/ali/?p=224">
	<link rel="alternate" type="application/json+oembed" href="http://watrax.com/2020/opfor/july/ali/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fwatrax.com%2F2020%2Fopfor%2Fjuly%2Fali%2Fexplore%2F">
	<link rel="alternate" type="text/xml+oembed" href="http://watrax.com/2020/opfor/july/ali/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fwatrax.com%2F2020%2Fopfor%2Fjuly%2Fali%2Fexplore%2F&amp;format=xml">
	<meta name="generator" content="WPML ver:4.3.16 stt:5,1;">
	<style></style>
	<meta property="og:site_name" content="Nooneen Design">
	<meta property="og:title" content="Explore">
	<meta property="og:description"
		content="Our Main Gallery Interior Design Lounge Chairs Vivamus suscipit tortor eget felis porttitor volutpat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Nulla quis lorem ut libero malesuada feugiat. Pellentesque in ipsum id orci porta dapibus. Decor Placements…">
	<meta property="og:url" content="http://watrax.com/2020/opfor/july/ali/explore/">
	<meta property="og:type" content="article">
	<noscript>
		<style>
			.woocommerce-product-gallery {
				opacity: 1 !important;
			}
		</style>
	</noscript>
	<meta name="generator" content="Powered by Slider Revolution 6.2.10 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface.">
	<link rel="icon" href="http://watrax.com/2020/opfor/july/ali/wp-content/uploads/2020/07/Favicon.png" type="image/png" sizes="16x16">
	<link rel="icon" href="http://watrax.com/2020/opfor/july/ali/wp-content/uploads/2020/07/Favicon.png" type="image/png" sizes="32x32">
	<script type="text/javascript">
		function setREVStartSize(e) {
			//window.requestAnimationFrame(function() {
			window.RSIW = window.RSIW === undefined ? window.innerWidth : window.RSIW;
			window.RSIH = window.RSIH === undefined ? window.innerHeight : window.RSIH;
			try {
				var pw = document.getElementById(e.c).parentNode.offsetWidth,
					newh;
				pw = pw === 0 || isNaN(pw) ? window.RSIW : pw;
				e.tabw = e.tabw === undefined ? 0 : parseInt(e.tabw);
				e.thumbw = e.thumbw === undefined ? 0 : parseInt(e.thumbw);
				e.tabh = e.tabh === undefined ? 0 : parseInt(e.tabh);
				e.thumbh = e.thumbh === undefined ? 0 : parseInt(e.thumbh);
				e.tabhide = e.tabhide === undefined ? 0 : parseInt(e.tabhide);
				e.thumbhide = e.thumbhide === undefined ? 0 : parseInt(e.thumbhide);
				e.mh = e.mh === undefined || e.mh == "" || e.mh === "auto" ? 0 : parseInt(e.mh, 0);
				if (e.layout === "fullscreen" || e.l === "fullscreen")
					newh = Math.max(e.mh, window.RSIH);
				else {
					e.gw = Array.isArray(e.gw) ? e.gw : [e.gw];
					for (var i in e.rl)
						if (e.gw[i] === undefined || e.gw[i] === 0) e.gw[i] = e.gw[i - 1];
					e.gh = e.el === undefined || e.el === "" || (Array.isArray(e.el) && e.el.length == 0) ? e.gh : e.el;
					e.gh = Array.isArray(e.gh) ? e.gh : [e.gh];
					for (var i in e.rl)
						if (e.gh[i] === undefined || e.gh[i] === 0) e.gh[i] = e.gh[i - 1];

					var nl = new Array(e.rl.length),
						ix = 0,
						sl;
					e.tabw = e.tabhide >= pw ? 0 : e.tabw;
					e.thumbw = e.thumbhide >= pw ? 0 : e.thumbw;
					e.tabh = e.tabhide >= pw ? 0 : e.tabh;
					e.thumbh = e.thumbhide >= pw ? 0 : e.thumbh;
					for (var i in e.rl) nl[i] = e.rl[i] < window.RSIW ? 0 : e.rl[i];
					sl = nl[0];
					for (var i in nl)
						if (sl > nl[i] && nl[i] > 0) {
							sl = nl[i];
							ix = i;
						}
					var m = pw > (e.gw[ix] + e.tabw + e.thumbw) ? 1 : (pw - (e.tabw + e.thumbw)) / (e.gw[ix]);
					newh = (e.gh[ix] * m) + (e.tabh + e.thumbh);
				}
				if (window.rs_init_css === undefined) window.rs_init_css = document.head.appendChild(document.createElement("style"));
				document.getElementById(e.c).height = newh + "px";
				window.rs_init_css.innerHTML += "#" + e.c + "_wrapper { height: " + newh + "px }";
			} catch (e) {
				console.log("Failure at Presize of Slider:" + e)
			}
			//});
		};
	</script>
	<style>
		.pswp {
			display: none;
		}
	</style>
	<script type="text/javascript">
		jQuery(document).ready(function($) {
			$('#elementor-tab-content-1891').css('display', 'none').removeClass('elementor-active');
			$('#elementor-tab-title-1891').click(function() {
				$('#elementor-tab-content-1891').css('display', 'block').addClass('elementor-active');
			})
		})
	</script>
	<style id="the7-custom-inline-css" type="text/css">
		.sub-nav .menu-item i.fa,
		.sub-nav .menu-item i.fas,
		.sub-nav .menu-item i.far,
		.sub-nav .menu-item i.fab {
			text-align: center;
			width: 1.25em;
		}
	</style>
</head>

<body
	class="page-template-default page page-id-224 wp-custom-logo wp-embed-responsive theme-techreshape_v4.3 the7-core-ver-2.5.0.1 woocommerce-js title-off dt-responsive-on right-mobile-menu-close-icon ouside-menu-close-icon mobile-hamburger-close-bg-enable mobile-hamburger-close-bg-hover-enable  fade-medium-mobile-menu-close-icon fade-medium-menu-close-icon srcset-enabled btn-flat custom-btn-color custom-btn-hover-color phantom-sticky phantom-shadow-decoration phantom-custom-logo-on sticky-mobile-header top-header first-switch-logo-left first-switch-menu-right second-switch-logo-left second-switch-menu-right right-mobile-menu layzr-loading-on popup-message-style the7-ver-4.3 elementor-default elementor-page elementor-page-224 elementor-page-573 elementor-page-566 elementor-page-560 no-mobile closed-overlay-mobile-header"
	data-elementor-device-mode="desktop" data-new-gr-c-s-check-loaded="14.990.0" data-gr-ext-installed="">
	<!-- The7 4.3 -->







		<div id="main" class="sidebar-none sidebar-divider-vertical">


			<div class="main-gradient"></div>
			<div class="wf-wrap">
				<div class="wf-container-main">




					<div id="content" class="content" role="main">

						<div data-elementor-type="wp-page" data-elementor-id="224" class="elementor elementor-224" data-elementor-settings="[]">
							<div class="elementor-inner">
								<div class="elementor-section-wrap">

									<section class="elementor-element elementor-element-add5bf7 elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section"
										data-id="add5bf7" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
										<div class="elementor-container elementor-column-gap-default">
											<div class="elementor-row">
												<div class="elementor-element elementor-element-36753459 elementor-column elementor-col-100 elementor-top-column" data-id="36753459" data-element_type="column"
													data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
													<div class="elementor-column-wrap  elementor-element-populated">
														<div class="elementor-widget-wrap">
															<div class="elementor-element elementor-element-5f26b6f4 elementor-widget elementor-widget-heading" data-id="5f26b6f4" data-element_type="widget" data-widget_type="heading.default">
																<div class="elementor-widget-container">
																	<h1 class="elementor-heading-title elementor-size-default">معرض اعمالنا</h1>
																</div>
															</div>
															<div class="elementor-element elementor-element-5c1d1aec elementor-widget elementor-widget-text-editor" data-id="5c1d1aec" data-element_type="widget" data-widget_type="text-editor.default">
																<div class="elementor-widget-container">
																	<div class="elementor-text-editor elementor-clearfix">
																		<p>التصميم الداخلي</p>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</section>
									<section
										class="elementor-element elementor-element-702f49a1 elementor-section-content-middle elementor-reverse-mobile elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section"
										data-id="702f49a1" data-element_type="section">
										<div class="elementor-container elementor-column-gap-default">
											<div class="elementor-row">
												<div class="elementor-element elementor-element-a4e99b elementor-column elementor-col-50 elementor-top-column" data-id="a4e99b" data-element_type="column">
													<div class="elementor-column-wrap  elementor-element-populated">
														<div class="elementor-widget-wrap">
															<div class="elementor-element elementor-element-331b02aa elementor-widget elementor-widget-heading" data-id="331b02aa" data-element_type="widget" data-widget_type="heading.default">
																<div class="elementor-widget-container">
																	<h3 class="elementor-heading-title elementor-size-default">كرسي</h3>
																</div>
															</div>
															<div class="elementor-element elementor-element-648dbcf elementor-widget elementor-widget-text-editor" data-id="648dbcf" data-element_type="widget" data-widget_type="text-editor.default">
																<div class="elementor-widget-container">
																	<div class="elementor-text-editor elementor-clearfix">
																		<p>البساطه بكل معانيها في تصميم حديث بارجل طويله نحيفه من خشب الجوز، فهي تقدم لمسه متناغمه مع المساحه الموضوعه فيها. يصاحبها جلد طبيعي بنكهه فاتحه</p>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div class="elementor-element elementor-element-510ce08f elementor-column elementor-col-50 elementor-top-column" data-id="510ce08f" data-element_type="column">
													<div class="elementor-column-wrap  elementor-element-populated">
														<div class="elementor-widget-wrap">
															<div class="elementor-element elementor-element-187c36c8 elementor-widget elementor-widget-image" data-id="187c36c8" data-element_type="widget" data-widget_type="image.default">
																<div class="elementor-widget-container">
																	<div class="elementor-image">
																		<img width="1000" height="900" src="https://i.ibb.co/mNkK1TX/shutterstock-575914609.jpg" class="attachment-full size-full" alt=""
																			sizes="(max-width: 1000px) 100vw, 1000px"> </div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</section>
									<section class="elementor-element elementor-element-36826d12 elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section"
										data-id="36826d12" data-element_type="section">
										<div class="elementor-container elementor-column-gap-default">
											<div class="elementor-row">
												<div class="elementor-element elementor-element-421b879a elementor-column elementor-col-50 elementor-top-column" data-id="421b879a" data-element_type="column">
													<div class="elementor-column-wrap  elementor-element-populated">
														<div class="elementor-widget-wrap">
															<div class="elementor-element elementor-element-1c0d68f7 elementor-widget elementor-widget-image" data-id="1c0d68f7" data-element_type="widget" data-widget_type="image.default">
																<div class="elementor-widget-container">
																	<div class="elementor-image">
																		<img width="1000" height="900" src="https://i.ibb.co/CPfWzfL/shutterstock-483113125.jpg" class="attachment-full size-full" alt=""
																			sizes="(max-width: 1000px) 100vw, 1000px"> </div>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div class="elementor-element elementor-element-312e824e elementor-column elementor-col-50 elementor-top-column" data-id="312e824e" data-element_type="column">
													<div class="elementor-column-wrap  elementor-element-populated">
														<div class="elementor-widget-wrap">
															<div class="elementor-element elementor-element-3d879c26 elementor-widget elementor-widget-heading" data-id="3d879c26" data-element_type="widget" data-widget_type="heading.default">
																<div class="elementor-widget-container">
																	<h3 class="elementor-heading-title elementor-size-default">طاوله</h3>
																</div>
															</div>
															<div class="elementor-element elementor-element-e8de68e elementor-widget elementor-widget-text-editor" data-id="e8de68e" data-element_type="widget" data-widget_type="text-editor.default">
																<div class="elementor-widget-container">
																	<div class="elementor-text-editor elementor-clearfix">
																		<p>فكره الطاوله ان تخلق جو ناعم بارجل مخلوطه بماده الايبوكسي و الخشب الناعم بشكل دائري لتظهر بمنظر مختلف و جذاب في الجهه الاخري لديك زاويه صلبه و عريضه</p>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</section>
									<section class="elementor-element elementor-element-9c3dc7f elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="9c3dc7f"
										data-element_type="section">
										<div class="elementor-container elementor-column-gap-default">
											<div class="elementor-row">
												<div class="elementor-element elementor-element-d58b25a elementor-column elementor-col-66 elementor-top-column" data-id="d58b25a" data-element_type="column">
													<div class="elementor-column-wrap  elementor-element-populated">
														<div class="elementor-widget-wrap">
															<div class="elementor-element elementor-element-649f395 elementor-widget elementor-widget-gallery" data-id="649f395" data-element_type="widget"
																data-settings="{&quot;lazyload&quot;:&quot;yes&quot;,&quot;gallery_layout&quot;:&quot;grid&quot;,&quot;columns&quot;:4,&quot;columns_tablet&quot;:2,&quot;columns_mobile&quot;:1,&quot;gap&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:10,&quot;sizes&quot;:[]},&quot;gap_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:10,&quot;sizes&quot;:[]},&quot;gap_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:10,&quot;sizes&quot;:[]},&quot;link_to&quot;:&quot;file&quot;,&quot;aspect_ratio&quot;:&quot;3:2&quot;,&quot;overlay_background&quot;:&quot;yes&quot;,&quot;content_hover_animation&quot;:&quot;fade-in&quot;}"
																data-widget_type="gallery.default">
																<div class="elementor-widget-container">
																	<div class="elementor-gallery__container e-gallery-container e-gallery-grid e-gallery--ltr e-gallery--lazyload"
																		style="--hgap:10px; --vgap:10px; --animation-duration:350ms; --columns:4; --rows:2; --aspect-ratio:66.6667%; --container-aspect-ratio:33.2432%;">
																		<a class="e-gallery-item elementor-gallery-item elementor-animated-content" href="https://i.ibb.co/Qb7nJsd/shutterstock-43891231.jpg" data-elementor-open-lightbox="yes"
																			data-elementor-lightbox-slideshow="all-649f395" data-elementor-lightbox-title="coastal" style="--column:0; --row:0;">
																			<div class="e-gallery-image elementor-gallery-item__image" data-thumbnail="https://i.ibb.co/Qb7nJsd/shutterstock-43891231.jpg" data-width="300" data-height="300" alt=""></div>
																			<div class="elementor-gallery-item__overlay"></div>
																		</a>
																		<a class="e-gallery-item elementor-gallery-item elementor-animated-content" href="https://i.ibb.co/k1hdjch/shutterstock-128044820.jpg" data-elementor-open-lightbox="yes"
																			data-elementor-lightbox-slideshow="all-649f395" data-elementor-lightbox-title="g1" style="--column:1; --row:0;">
																			<div class="e-gallery-image elementor-gallery-item__image" data-thumbnail="https://i.ibb.co/k1hdjch/shutterstock-128044820.jpg" data-width="300" data-height="300" alt=""></div>
																			<div class="elementor-gallery-item__overlay"></div>
																		</a>
																		<a class="e-gallery-item elementor-gallery-item elementor-animated-content" href="https://i.ibb.co/8cxQpXy/shutterstock-235629970.jpg" data-elementor-open-lightbox="yes"
																			data-elementor-lightbox-slideshow="all-649f395" data-elementor-lightbox-title="g2" style="--column:2; --row:0;">
																			<div class="e-gallery-image elementor-gallery-item__image" data-thumbnail="https://i.ibb.co/8cxQpXy/shutterstock-235629970.jpg" data-width="300" data-height="300" alt=""></div>
																			<div class="elementor-gallery-item__overlay"></div>
																		</a>
																		<a class="e-gallery-item elementor-gallery-item elementor-animated-content" href="https://i.ibb.co/ZH6jL6Q/shutterstock-346126697.jpg" data-elementor-open-lightbox="yes"
																			data-elementor-lightbox-slideshow="all-649f395" data-elementor-lightbox-title="transitional" style="--column:3; --row:0;">
																			<div class="e-gallery-image elementor-gallery-item__image" data-thumbnail="https://i.ibb.co/ZH6jL6Q/shutterstock-346126697.jpg" data-width="300" data-height="300" alt="">
																			</div>
																			<div class="elementor-gallery-item__overlay"></div>
																		</a>
																		<a class="e-gallery-item elementor-gallery-item elementor-animated-content" href="https://i.ibb.co/844tG0P/shutterstock-363430451.jpg" data-elementor-open-lightbox="yes"
																			data-elementor-lightbox-slideshow="all-649f395" data-elementor-lightbox-title="preppy" style="--column:0; --row:1;">
																			<div class="e-gallery-image elementor-gallery-item__image" data-thumbnail="https://i.ibb.co/844tG0P/shutterstock-363430451.jpg" data-width="300" data-height="300" alt=""></div>
																			<div class="elementor-gallery-item__overlay"></div>
																		</a>
																		<a class="e-gallery-item elementor-gallery-item elementor-animated-content" href="https://i.ibb.co/GTJgGh9/shutterstock-427241281.jpg" data-elementor-open-lightbox="yes"
																			data-elementor-lightbox-slideshow="all-649f395" data-elementor-lightbox-title="g3" style="--column:1; --row:1;">
																			<div class="e-gallery-image elementor-gallery-item__image" data-thumbnail="https://i.ibb.co/GTJgGh9/shutterstock-427241281.jpg" data-width="300" data-height="300" alt=""></div>
																			<div class="elementor-gallery-item__overlay"></div>
																		</a>
																		<a class="e-gallery-item elementor-gallery-item elementor-animated-content" href="https://i.ibb.co/p2HT6fW/shutterstock-483113092.jpg" data-elementor-open-lightbox="yes"
																			data-elementor-lightbox-slideshow="all-649f395" data-elementor-lightbox-title="PArallell-Image" style="--column:2; --row:1;">
																			<div class="e-gallery-image elementor-gallery-item__image" data-thumbnail="https://i.ibb.co/p2HT6fW/shutterstock-483113092.jpg" data-width="300" data-height="300" alt="">
																			</div>
																			<div class="elementor-gallery-item__overlay"></div>
																		</a>
																		<a class="e-gallery-item elementor-gallery-item elementor-animated-content" href="https://i.ibb.co/whXbvNt/shutterstock-495158539.jpg" data-elementor-open-lightbox="yes"
																			data-elementor-lightbox-slideshow="all-649f395" data-elementor-lightbox-title="parallell-iamge2" style="--column:3; --row:1;">
																			<div class="e-gallery-image elementor-gallery-item__image" data-thumbnail="https://i.ibb.co/whXbvNt/shutterstock-495158539.jpg" data-width="300" data-height="300" alt="">
																			</div>
																			<div class="elementor-gallery-item__overlay"></div>
																		</a>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div class="elementor-element elementor-element-1d9532a elementor-column elementor-col-33 elementor-top-column" data-id="1d9532a" data-element_type="column">
													<div class="elementor-column-wrap  elementor-element-populated">
														<div class="elementor-widget-wrap">
															<div class="elementor-element elementor-element-6afd53c elementor-widget elementor-widget-heading" data-id="6afd53c" data-element_type="widget" data-widget_type="heading.default">
																<div class="elementor-widget-container">
																	<h3 class="elementor-heading-title elementor-size-default">معرض اعمالنا</h3>
																</div>
															</div>
															<div class="elementor-element elementor-element-a426f25 elementor-widget elementor-widget-text-editor" data-id="a426f25" data-element_type="widget" data-widget_type="text-editor.default">
																<div class="elementor-widget-container">
																	<div class="elementor-text-editor elementor-clearfix">
																	<p>بامكانك الغوص في قسم المعرض و استعراض ما تحلو به نفسك من تصاميم مختاره منا بذوق رفيع و ان اعجبك شئ فنحن بخدمتك.</p>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</section>
								</div>
							</div>
						</div>

					</div><!-- #content -->




				</div><!-- .wf-container -->
			</div><!-- .wf-wrap -->


		</div><!-- #main -->






		<a href="http://watrax.com/2020/opfor/july/ali/explore/#" class="scroll-top on"><span class="screen-reader-text">Go to Top</span></a>

	</div><!-- #page -->


	<div id="fb-root"></div>
	<script>
		(function(d, s, id) {
			var js, fjs = d.getElementsByTagName(s)[0];
			js = d.createElement(s);
			js.id = id;
			js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js#xfbml=1&version=v6.0&autoLogAppEvents=1';
			fjs.parentNode.insertBefore(js, fjs);
		}(document, 'script', 'facebook-jssdk'));
	</script>
	<div class="fb-customerchat" attribution="wordpress" attribution_version="1.7" page_id="102395284936848">
	</div>
	<script type="text/javascript">
		var c = document.body.className;
		c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
		document.body.className = c;
	</script>
	<link rel="stylesheet" id="elementor-gallery-css" href="/Explore – Nooneen Design_files/e-gallery.min.css" type="text/css" media="all">
	<script type="text/javascript" src="/Explore – Nooneen Design_files/main.min.js"></script>
	<script type="text/javascript">
		/* <![CDATA[ */
		var wpcf7 = {
			"apiSettings": {
				"root": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-json\/contact-form-7\/v1",
				"namespace": "contact-form-7\/v1"
			}
		};
		/* ]]> */
	</script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/scripts(1).js"></script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/jquery.blockUI.min.js"></script>
	<script type="text/javascript">
		/* <![CDATA[ */
		var wc_add_to_cart_params = {
			"ajax_url": "\/2020\/opfor\/july\/ali\/wp-admin\/admin-ajax.php",
			"wc_ajax_url": "\/2020\/opfor\/july\/ali\/?wc-ajax=%%endpoint%%",
			"i18n_view_cart": "View cart",
			"cart_url": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/cart\/",
			"is_cart": "",
			"cart_redirect_after_add": "yes"
		};
		/* ]]> */
	</script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/add-to-cart.min.js"></script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/js.cookie.min.js"></script>
	<script type="text/javascript">
		/* <![CDATA[ */
		var woocommerce_params = {
			"ajax_url": "\/2020\/opfor\/july\/ali\/wp-admin\/admin-ajax.php",
			"wc_ajax_url": "\/2020\/opfor\/july\/ali\/?wc-ajax=%%endpoint%%"
		};
		/* ]]> */
	</script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/woocommerce.min.js"></script>
	<script type="text/javascript">
		/* <![CDATA[ */
		var wc_cart_fragments_params = {
			"ajax_url": "\/2020\/opfor\/july\/ali\/wp-admin\/admin-ajax.php",
			"wc_ajax_url": "\/2020\/opfor\/july\/ali\/?wc-ajax=%%endpoint%%",
			"cart_hash_key": "wc_cart_hash_cf278bc9cde494c8800f49904f9839a2",
			"fragment_name": "wc_fragments_cf278bc9cde494c8800f49904f9839a2",
			"request_timeout": "5000"
		};
		/* ]]> */
	</script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/cart-fragments.min.js"></script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/wp-embed.min.js"></script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/imagesloaded.min.js"></script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/e-gallery.min.js"></script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/jquery.smartmenus.min.js"></script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/frontend-modules.min.js"></script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/jquery.sticky.min.js"></script>
	<script type="text/javascript">
		var ElementorProFrontendConfig = {
			"ajaxurl": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-admin\/admin-ajax.php",
			"nonce": "53e5983993",
			"i18n": {
				"toc_no_headings_found": "No headings were found on this page."
			},
			"shareButtonsNetworks": {
				"facebook": {
					"title": "Facebook",
					"has_counter": true
				},
				"twitter": {
					"title": "Twitter"
				},
				"google": {
					"title": "Google+",
					"has_counter": true
				},
				"linkedin": {
					"title": "LinkedIn",
					"has_counter": true
				},
				"pinterest": {
					"title": "Pinterest",
					"has_counter": true
				},
				"reddit": {
					"title": "Reddit",
					"has_counter": true
				},
				"vk": {
					"title": "VK",
					"has_counter": true
				},
				"odnoklassniki": {
					"title": "OK",
					"has_counter": true
				},
				"tumblr": {
					"title": "Tumblr"
				},
				"delicious": {
					"title": "Delicious"
				},
				"digg": {
					"title": "Digg"
				},
				"skype": {
					"title": "Skype"
				},
				"stumbleupon": {
					"title": "StumbleUpon",
					"has_counter": true
				},
				"mix": {
					"title": "Mix"
				},
				"telegram": {
					"title": "Telegram"
				},
				"pocket": {
					"title": "Pocket",
					"has_counter": true
				},
				"xing": {
					"title": "XING",
					"has_counter": true
				},
				"whatsapp": {
					"title": "WhatsApp"
				},
				"email": {
					"title": "Email"
				},
				"print": {
					"title": "Print"
				}
			},
			"menu_cart": {
				"cart_page_url": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/cart\/",
				"checkout_page_url": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/checkout\/"
			},
			"facebook_sdk": {
				"lang": "en_US",
				"app_id": ""
			},
			"lottie": {
				"defaultAnimationUrl": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json"
			}
		};
	</script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/frontend.min.js"></script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/position.min.js"></script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/dialog.min.js"></script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/waypoints.min.js"></script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/swiper.min.js"></script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/share-link.min.js"></script>
	<script type="text/javascript">
		var elementorFrontendConfig = {
			"environmentMode": {
				"edit": false,
				"wpPreview": false
			},
			"i18n": {
				"shareOnFacebook": "Share on Facebook",
				"shareOnTwitter": "Share on Twitter",
				"pinIt": "Pin it",
				"downloadImage": "Download image"
			},
			"is_rtl": false,
			"breakpoints": {
				"xs": 0,
				"sm": 480,
				"md": 768,
				"lg": 1025,
				"xl": 1440,
				"xxl": 1600
			},
			"version": "2.9.14",
			"urls": {
				"assets": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/plugins\/elementor\/assets\/"
			},
			"settings": {
				"page": [],
				"general": {
					"elementor_global_image_lightbox": "yes",
					"elementor_lightbox_enable_counter": "yes",
					"elementor_lightbox_enable_fullscreen": "yes",
					"elementor_lightbox_enable_zoom": "yes",
					"elementor_lightbox_enable_share": "yes",
					"elementor_lightbox_title_src": "title",
					"elementor_lightbox_description_src": "description"
				},
				"editorPreferences": []
			},
			"post": {
				"id": 224,
				"title": "Explore%20%E2%80%93%20Nooneen%20Design",
				"excerpt": "",
				"featuredImage": false
			}
		};
	</script>
	<script type="text/javascript" src="/Explore – Nooneen Design_files/frontend.min(2).js"></script><span id="elementor-device-mode" class="elementor-screen-only"></span>
	<div class="pafe-break-point" data-pafe-break-point-md="768" data-pafe-break-point-lg="1025" data-pafe-ajax-url="http://watrax.com/2020/opfor/july/ali/wp-admin/admin-ajax.php"></div>
	<div data-pafe-form-builder-tinymce-upload="http://watrax.com/2020/opfor/july/ali/wp-content/plugins/piotnet-addons-for-elementor-pro/inc/tinymce/tinymce-upload.php"></div>
	<div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="pswp__bg"></div>
		<div class="pswp__scroll-wrap">
			<div class="pswp__container">
				<div class="pswp__item"></div>
				<div class="pswp__item"></div>
				<div class="pswp__item"></div>
			</div>
			<div class="pswp__ui pswp__ui--hidden">
				<div class="pswp__top-bar">
					<div class="pswp__counter"></div>
					<button class="pswp__button pswp__button--close" title="Close (Esc)" aria-label="Close (Esc)"></button>
					<button class="pswp__button pswp__button--share" title="Share" aria-label="Share"></button>
					<button class="pswp__button pswp__button--fs" title="Toggle fullscreen" aria-label="Toggle fullscreen"></button>
					<button class="pswp__button pswp__button--zoom" title="Zoom in/out" aria-label="Zoom in/out"></button>
					<div class="pswp__preloader">
						<div class="pswp__preloader__icn">
							<div class="pswp__preloader__cut">
								<div class="pswp__preloader__donut"></div>
							</div>
						</div>
					</div>
				</div>
				<div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
					<div class="pswp__share-tooltip"></div>
				</div>
				<button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)" aria-label="Previous (arrow left)">
				</button>
				<button class="pswp__button pswp__button--arrow--right" title="Next (arrow right)" aria-label="Next (arrow right)">
				</button>
				<div class="pswp__caption">
					<div class="pswp__caption__center"></div>
				</div>
			</div>
		</div>
	</div>


	<div class="mobile-sticky-header-overlay"></div>
	<div class="mobile-sticky-sidebar-overlay"></div>
	<div class="iso-preloader dt-posts-preload dt-posts-preload-active" style="display: none;">
		<div class="dt-posts-preload-activity"></div>
	</div>
</body>

</html>





@endsection
