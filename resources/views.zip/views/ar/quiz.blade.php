@extends('ar.layout')
@section('content')

	<link rel="stylesheet" id="wp-block-library-css" href="/Quiz – Nooneen Design_files/style.min.css" type="text/css" media="all">
<link rel="stylesheet" id="wp-block-library-theme-css" href="/Quiz – Nooneen Design_files/theme.min.css" type="text/css" media="all">
<link rel="stylesheet" id="wc-block-vendors-style-css" href="/Quiz – Nooneen Design_files/vendors-style.css" type="text/css" media="all">
<link rel="stylesheet" id="wc-block-style-css" href="/Quiz – Nooneen Design_files/style.css" type="text/css" media="all">
<link rel="stylesheet" id="contact-form-7-css" href="/Quiz – Nooneen Design_files/styles.css" type="text/css" media="all">
<link rel="stylesheet" id="dq-bs-style-css" href="/Quiz – Nooneen Design_files/bootstrap.min.css" type="text/css" media="all">
<link rel="stylesheet" id="dq-fontawesome-css" href="/Quiz – Nooneen Design_files/pro.min.css" type="text/css" media="all">
<link rel="stylesheet" id="dq-slick-css-css" href="/Quiz – Nooneen Design_files/slick.min.css" type="text/css" media="all">
<link rel="stylesheet" id="dq-slick-theme-css-css" href="/Quiz – Nooneen Design_files/slick-theme.min.css" type="text/css" media="all">
<link rel="stylesheet" id="dq-style-css" href="/Quiz – Nooneen Design_files/style(1).css" type="text/css" media="all">
<link rel="stylesheet" id="dq-responsive-style-css" href="/Quiz – Nooneen Design_files/responsive.css" type="text/css" media="all">
<link rel="stylesheet" id="pafe-extension-style-css" href="/Quiz – Nooneen Design_files/extension.min.css" type="text/css" media="all">
<link rel="stylesheet" id="pafe-woocommerce-sales-funnels-style-css" href="/Quiz – Nooneen Design_files/woocommerce-sales-funnels.min.css" type="text/css" media="all">
<link rel="stylesheet" id="rs-plugin-settings-css" href="/Quiz – Nooneen Design_files/rs6.css" type="text/css" media="all">
<style id="rs-plugin-settings-inline-css" type="text/css">
#rs-demo-id {}
</style>
<style id="woocommerce-inline-inline-css" type="text/css">
.woocommerce form .form-row .required { visibility: visible; }
</style>


<body class="page-template page-template-elementor_header_footer page page-id-362 wp-custom-logo wp-embed-responsive theme-techreshape_v4.3 the7-core-ver-2.5.0.1 woocommerce-js dt-responsive-on right-mobile-menu-close-icon ouside-menu-close-icon mobile-hamburger-close-bg-enable mobile-hamburger-close-bg-hover-enable  fade-medium-mobile-menu-close-icon fade-medium-menu-close-icon srcset-enabled btn-flat custom-btn-color custom-btn-hover-color phantom-sticky phantom-shadow-decoration phantom-custom-logo-on sticky-mobile-header top-header first-switch-logo-left first-switch-menu-right second-switch-logo-left second-switch-menu-right right-mobile-menu layzr-loading-on popup-message-style the7-ver-4.3 elementor-default elementor-template-full-width elementor-clear-template elementor-page elementor-page-362 elementor-page-573 elementor-page-566 elementor-page-560 no-mobile closed-overlay-mobile-header" data-elementor-device-mode="desktop" data-new-gr-c-s-check-loaded="14.990.0" data-gr-ext-installed="">
<!-- The7 4.3 -->



	<div class="header-space sticky-space-off" style="height: 90px;"></div>
	<div class="dt-mobile-header mobile-menu-show-divider dt-parent-menu-clickable">
		<div class="mobile-header-scrollbar-wrap">
			<div class="dt-close-mobile-menu-icon">
				<div class="close-line-wrap"><span class="close-line"></span><span class="close-line"></span><span class="close-line"></span></div>
			</div>
			<ul id="mobile-menu" class="mobile-main-nav" role="navigation">
				<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-141 first has-children"><a href="http://watrax.com/2020/opfor/july/ali/login/#" data-level="1"><span class="menu-item-text"><span
								class="menu-text">How Its Work</span></span></a><i class="next-level-button"></i>
					<ul class="sub-nav level-arrows-on">
						<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-705 first"><a href="http://watrax.com/2020/opfor/july/ali/design-process/" data-level="2"><span class="menu-item-text"><span class="menu-text">Design
										Process</span></span></a></li>
						<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-243"><a href="http://watrax.com/2020/opfor/july/ali/pricing/" data-level="2"><span class="menu-item-text"><span class="menu-text">Pricing</span></span></a>
						</li>
					</ul>
				</li>
				<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-601 has-children"><a href="http://watrax.com/2020/opfor/july/ali/designer/" data-level="1"><span class="menu-item-text"><span
								class="menu-text">Designer</span></span></a><i class="next-level-button"></i>
					<ul class="sub-nav level-arrows-on">
						<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-665 first"><a href="http://watrax.com/2020/opfor/july/ali/login/#" data-level="2"><span class="menu-item-text"><span
										class="menu-text">Classic</span></span></a></li>
						<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-666"><a href="http://watrax.com/2020/opfor/july/ali/login/#" data-level="2"><span class="menu-item-text"><span class="menu-text">Elite</span></span></a></li>
					</ul>
				</li>
				<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-223 has-children"><a href="http://watrax.com/2020/opfor/july/ali/stories/" data-level="1"><span class="menu-item-text"><span
								class="menu-text">Stories</span></span></a><i class="next-level-button"></i>
					<ul class="sub-nav level-arrows-on">
						<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-668 first"><a href="http://watrax.com/2020/opfor/july/ali/reviews/" data-level="2"><span class="menu-item-text"><span
										class="menu-text">Reviews</span></span></a></li>
					</ul>
				</li>
				<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-226"><a href="http://watrax.com/2020/opfor/july/ali/explore/" data-level="1"><span class="menu-item-text"><span class="menu-text">Our Gallery</span></span></a>
				</li>
				<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-321"><a href="http://watrax.com/2020/opfor/july/ali/order/" data-level="1"><span class="menu-item-text"><span class="menu-text">Shop</span></span></a></li>
				<li class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-627 current_page_item menu-item-708 act"><a href="http://watrax.com/2020/opfor/july/ali/login/" data-level="1"><span
							class="menu-item-text"><span class="menu-text">Login</span></span></a></li>
				<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-711"><a href="http://watrax.com/2020/opfor/july/ali/regist/" data-level="1"><span class="menu-item-text"><span class="menu-text">Register</span></span></a></li>
				<li class="menu-item wpml-ls-slot-17 wpml-ls-item wpml-ls-item-en wpml-ls-current-language wpml-ls-menu-item wpml-ls-first-item wpml-ls-last-item menu-item-type-wpml_ls_menu_item menu-item-object-wpml_ls_menu_item menu-item-wpml-ls-17-en">
					<a href="http://watrax.com/2020/opfor/july/ali/login/" data-level="1"><span class="menu-item-text"><span class="menu-text"><img class="wpml-ls-flag" src="/Login – Nooneen Design_files/en.png" alt="English"></span></span></a></li>
			</ul>
			<div class="mobile-mini-widgets-in-menu first-switch-no-widgets"><a href="http://watrax.com/2020/opfor/july/ali/quiz/"
					class="microwidget-btn mini-button header-elements-button-1 show-on-desktop near-logo-first-switch in-menu-second-switch microwidget-btn-bg-on microwidget-btn-hover-bg-on disable-animation-bg border-off hover-border-off btn-icon-align-right first last hide-on-desktop hide-on-first-switch show-on-second-switch"><span>Get
						Started</span></a></div>
		</div>
	</div>



<div id="main" class="sidebar-none sidebar-divider-vertical">


	<div class="main-gradient"></div>
	<div class="wf-wrap">
	<div class="wf-container-main">




	<div id="content" class="content" role="main">

				<div data-elementor-type="wp-page" data-elementor-id="362" class="elementor elementor-362" data-elementor-settings="[]">
			<div class="elementor-inner">
				<div class="elementor-section-wrap">
							<section class="elementor-element elementor-element-be4bf04 elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="be4bf04" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div class="elementor-element elementor-element-2cc625d elementor-column elementor-col-100 elementor-top-column" data-id="2cc625d" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div class="elementor-element elementor-element-1fd3951 elementor-widget elementor-widget-shortcode" data-id="1fd3951" data-element_type="widget" data-widget_type="shortcode.default">
				<div class="elementor-widget-container">
					<div class="elementor-shortcode">	<div id="interior-design-quiz">
		<!-- Style Section -->
		<div class="style-section section container">
			<div class="step style-step-1 row active">
				<div class="section-left col-md-12 col-lg-4">
					<h3 class="section-title">اختر الغرفه التي تري نفسك فيها</h3>

				</div>
				<div class="section-right col-md-12 col-lg-7">
					<div class="portfolio row masonry" data-target=".item" data-col-xs="12" data-col-sm="4" data-col-md="4">
												<div class="col-xs-12 col-sm-4 col-md-4">
							<div class="item multiple">
								<input type="checkbox" name="portfolio-select" class="quiz-checkbox" value="599"><img width="800" height="816" src="/Quiz – Nooneen Design_files/2826fd4c-401d-4d63-b44c-408c3a3fd357.png" class="attachment-full size-full wp-post-image" alt=""  sizes="(max-width: 800px) 100vw, 800px">								<div class="select-icon">
									<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
								</div>
							</div>
						</div>
												<div class="col-xs-12 col-sm-4 col-md-4">
							<div class="item multiple">
								<input type="checkbox" name="portfolio-select" class="quiz-checkbox" value="585"><img width="800" height="816" src="/Quiz – Nooneen Design_files/c96bced9-8cab-4d3e-9e4b-d3c7008d17bf.png" class="attachment-full size-full wp-post-image" alt=""  sizes="(max-width: 800px) 100vw, 800px">								<div class="select-icon">
									<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
								</div>
							</div>
						</div>
												<div class="col-xs-12 col-sm-4 col-md-4">
							<div class="item multiple">
								<input type="checkbox" name="portfolio-select" class="quiz-checkbox" value="579"><img width="800" height="816" src="/Quiz – Nooneen Design_files/e319ac0c-8941-47a8-92dd-7ad2816dfdb1.png" class="attachment-full size-full wp-post-image" alt=""  sizes="(max-width: 800px) 100vw, 800px">								<div class="select-icon">
									<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
								</div>
							</div>
						</div>
												<div class="col-xs-12 col-sm-4 col-md-4">
							<div class="item multiple">
								<input type="checkbox" name="portfolio-select" class="quiz-checkbox" value="574"><img width="800" height="816" src="/Quiz – Nooneen Design_files/965ae9f3-c622-4725-98d2-fff09a688a91.png" class="attachment-full size-full wp-post-image" alt=""  sizes="(max-width: 800px) 100vw, 800px">								<div class="select-icon">
									<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
								</div>
							</div>
						</div>
												<div class="col-xs-12 col-sm-4 col-md-4">
							<div class="item multiple active">
								<input type="checkbox" name="portfolio-select" class="quiz-checkbox" value="570"><img width="800" height="816" src="/Quiz – Nooneen Design_files/140dfcf5-76cc-41cb-85dd-9c4559450184.png" class="attachment-full size-full wp-post-image" alt=""  sizes="(max-width: 800px) 100vw, 800px">								<div class="select-icon">
									<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
								</div>
							</div>
						</div>
												<div class="col-xs-12 col-sm-4 col-md-4">
							<div class="item multiple">
								<input type="checkbox" name="portfolio-select" class="quiz-checkbox" value="558"><img width="800" height="816" src="/Quiz – Nooneen Design_files/4019be41-2d03-403d-9bc7-eb31fb75a795.png" class="attachment-full size-full wp-post-image" alt=""  sizes="(max-width: 800px) 100vw, 800px">								<div class="select-icon">
									<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
								</div>
							</div>
						</div>
												<div class="col-xs-12 col-sm-4 col-md-4">
							<div class="item multiple">
								<input type="checkbox" name="portfolio-select" class="quiz-checkbox" value="551"><img width="800" height="816" src="/Quiz – Nooneen Design_files/6e547b67-f2c5-4ac9-8627-15435857e499.png" class="attachment-full size-full wp-post-image" alt="briana"  sizes="(max-width: 800px) 100vw, 800px">								<div class="select-icon">
									<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
								</div>
							</div>
						</div>
												<div class="col-xs-12 col-sm-4 col-md-4">
							<div class="item multiple">
								<input type="checkbox" name="portfolio-select" class="quiz-checkbox" value="540"><img width="800" height="816" src="/Quiz – Nooneen Design_files/346090e8-3773-4588-a376-0fea63ddda72.png" class="attachment-full size-full wp-post-image" alt="Eclectic, Transitional Patio" sizes="(max-width: 800px) 100vw, 800px">								<div class="select-icon">
									<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
								</div>
							</div>
						</div>
												<div class="col-xs-12 col-sm-4 col-md-4">
							<div class="item multiple">
								<input type="checkbox" name="portfolio-select" class="quiz-checkbox" value="424"><img width="1920" style="height:170px" height="1080" src="/Quiz – Nooneen Design_files/b0617ebb-2922-4514-bb2b-2d5c4a87fb29.jpg" class="attachment-full size-full wp-post-image" alt=""  sizes="(max-width: 1920px) 100vw, 1920px">								<div class="select-icon">
									<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
								</div>
							</div>
						</div>
											</div>

				</div>
				<div class="quiz-footer">
					<button class="btn-next" value="Next">التالي</button>
				</div>
			</div>

			<div class="step style-step-2 row ">
				<div class="section-left col-md-12 col-lg-5">
					<h3 class="section-title">كم تعرف عن التصميم الداخلي ؟</h3>
				</div>

				<div class="section-right col-md-12 col-lg-7">
					<div class="design-sense row round-checkbox">
						<div class="col-md-4 col-lg-4">
							<div class="item">
								<div class="item-inner">
									<input type="checkbox" name="design-sense-select" class="quiz-checkbox" value="pro">
									<img src="/Quiz – Nooneen Design_files/user.png">
									<h3>انا خبر</h3>
									<div class="select-icon">
										<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
									</div>
								</div>
							</div>
						</div>

						<div class="col-md-4 col-lg-4">
							<div class="item">
								<div class="item-inner">
									<input type="checkbox" name="design-sense-select" class="quiz-checkbox" value="dabbled">
									<img src="/Quiz – Nooneen Design_files/idea.png">
									<h3>عندي فكره</h3>
									<div class="select-icon">
										<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
									</div>
								</div>
							</div>
						</div>

						<div class="col-md-4 col-lg-4">
							<div class="item">
								<div class="item-inner">
									<input type="checkbox" name="design-sense-select" class="quiz-checkbox" value="noob">
									<img src="/Quiz – Nooneen Design_files/emoji.png">
									<h3>حديث ب الامر</h3>
									<div class="select-icon">
										<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
									</div>
								</div>
							</div>
						</div>

					</div>
				</div>
			</div>

			<div class="step style-step-3 row">
				<div class="section-left col-md-12 col-lg-5">
					<h3 class="section-title">ما هي الغرفه التي تريد العمل بها </h3>
				</div>

				<div class="section-right col-md-12 col-lg-7">
					<div class="rooms-list row round-checkbox">
						<div class="col-md-2 col-lg-3">
							<div class="item multiple">
								<div class="item-inner">
									<input type="checkbox" name="rooms-select" class="quiz-checkbox" value="LivingRoom">
									<img src="/Quiz – Nooneen Design_files/living-room.png">
									<h3>عرفه المعيشه</h3>
									<div class="select-icon">
										<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
									</div>
								</div>
							</div>
						</div>

						<div class="col-md-2 col-lg-3">
							<div class="item multiple">
								<div class="item-inner">
									<input type="checkbox" name="rooms-select" class="quiz-checkbox" value="DiningRoom">
									<img src="/Quiz – Nooneen Design_files/dining-room.png">
									<h3>غرفه الطعام</h3>
									<div class="select-icon">
										<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
									</div>
								</div>
							</div>
						</div>

						<div class="col-md-2 col-lg-3">
							<div class="item multiple">
								<div class="item-inner">
									<input type="checkbox" name="rooms-select" class="quiz-checkbox" value="Bedroom">
									<img src="/Quiz – Nooneen Design_files/bed.png">
									<h3>غرفه النوم</h3>
									<div class="select-icon">
										<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
									</div>
								</div>
							</div>
						</div>

						<div class="col-md-2 col-lg-3">
							<div class="item multiple">
								<div class="item-inner">
									<input type="checkbox" name="rooms-select" class="quiz-checkbox" value="FamilyRoom">
									<img src="/Quiz – Nooneen Design_files/sofa.png">
									<h3>دوره المياه</h3>
									<div class="select-icon">
										<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
									</div>
								</div>
							</div>
						</div>

					</div>
				</div>
				<div class="quiz-footer">
					<button class="btn-next" value="Next">التالي</button>
				</div>
			</div>

			<div class="step style-step-3a row">
				<div class="section-left col-md-12 col-lg-5">
					<h3 class="section-title">Great! Which room should we focus on first?</h3>
				</div>

				<div class="section-right col-md-12 col-lg-7">
					<div class="room-priority row round-checkbox">
					</div>
					<div class="more-rooms-toggle">View all Options
						<i class="far fa-chevron-down"></i>
					</div>
					<div class="rooms-more row round-checkbox">
					</div>
				</div>
			</div>

			<div class="step style-step-4 row">
				<div class="section-left col-md-12 col-lg-5">
					<h3 class="section-title">اخبرنا اسمك.</h3>
					<p></p>
				</div>

				<div class="section-right col-md-12 col-lg-7">
					<div class="write-client-name row">
						<div class="col-md-12">
							<input type="text" class="client_name" name="client_name" placeholder="type your name">
						</div>
					</div>
				</div>
				<script>

				function press(){
					document.getElementById("needs").click(); // Click on the checkbox
					document.getElementById("start").click(); // Click on the checkbox

				}
				</script>
				<div class="quiz-footer">
					<button class="btn-next" onclick="press()" value="Next">Next</button>
				</div>
			</div>

			<div class="step style-step-5 row">
				<div class="col-md-12">
					<h3 class="section-title">اهلا بك <span class="client-name"></span>!</h3>
				</div>
			</div>

		</div>

		<div class="quiz-tabs">
			<div class="quiz-tabs-title">
				<div class="style-tab tab-title active">
					<a class="title"><span>1. </span>نتيجه الاختبار</a>
				</div>

				<div class="needs-tab tab-title" id="needs">
					<a class="title"><span>2. </span>احتياجاتك</a>
				</div>

				<div class="designer-tab tab-title">
					<a class="title"><span>3. </span>اختر مصمم</a>
				</div>

				<div class="package-tab tab-title">
					<a class="title"><span>4. </span>اختر باقه</a>
				</div>

			</div>
			<div class="quiz-tabs-content container">
				<div class="style-content tab-content active">
					<div class="row">
						<div class="col-md-12">
							<h3 class="your-style"><span></span></h3>
							<div class="quiz-footer">
								<button class="btn-next" value="Next">التالي</button>
							</div>
						</div>
					</div>
				</div>

				<div class="needs-content tab-content">
					<div class="row needs-prestep">
						<div class="needs-content-title col-md-12 text-center">
							<p><strong>Let's show you our best designers.</strong> We're going to ask you a few more questions to find just the right fit.</p>
						</div>
						<div class="col-md-12 get-started-btn-wrap text-center">
							<button class="btn-black btn-get-started"  id="start" value="Let&#39;s Get Started">Let's Get Started.</button>
						</div>
						<div class="col-md-12 no-thanks-btn-wrap text-center">
							<a href="http://watrax.com/2020/opfor/july/ali/quiz/#" class="no-thanks-btn">No thanks – Skip these questions</a>
						</div>
					</div>

					<!--  Needs Step 1  -->
					<div class="step needs-step-1 row">
						<div class="section-left col-md-12 col-lg-5">
							<h3 class="section-title">ما نوع السكن الذي تعيش فيه</h3>
						</div>

						<div class="section-right col-md-12 col-lg-7">
							<div class="home-type row round-checkbox">
								<div class="col-md-4 col-lg-4">
									<div class="item">
										<div class="item-inner">
											<input type="checkbox" name="design-sense-select" class="quiz-checkbox" value="house">
											<img src="/Quiz – Nooneen Design_files/House.svg">
											<h3>منزل</h3>
											<div class="select-icon">
												<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
											</div>
										</div>
									</div>
								</div>

								<div class="col-md-4 col-lg-4">
									<div class="item">
										<div class="item-inner">
											<input type="checkbox" name="design-sense-select" class="quiz-checkbox" value="townhouse">
											<img src="/Quiz – Nooneen Design_files/Townhouse.svg">
											<h3>دوبلكس</h3>
											<div class="select-icon">
												<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
											</div>
										</div>
									</div>
								</div>

								<div class="col-md-4 col-lg-4">
									<div class="item">
										<div class="item-inner">
											<input type="checkbox" name="design-sense-select" class="quiz-checkbox" value="apartment">
											<img src="/Quiz – Nooneen Design_files/Apartment.svg">
											<h3>شقه</h3>
											<div class="select-icon">
												<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
											</div>
										</div>
									</div>
								</div>

							</div>
						</div>
					</div>

					<!--  Needs Step 2  -->
					<div class="step needs-step-2 row">
						<div class="section-left col-md-12 col-lg-5">
							<h3 class="section-title">هل انت مأجر او مالك للمكان</h3>
						</div>

						<div class="section-right col-md-12 col-lg-7">
							<div class="space-status row round-checkbox">
								<div class="col-md-4 col-lg-6">
									<div class="item">
										<div class="item-inner">
											<input type="checkbox" name="design-sense-select" class="quiz-checkbox" value="Rent">
											<img src="/Quiz – Nooneen Design_files/Rent.svg">
											<h3>تأجير</h3>
											<div class="select-icon">
												<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
											</div>
										</div>
									</div>
								</div>

								<div class="col-md-4 col-lg-6">
									<div class="item">
										<div class="item-inner">
											<input type="checkbox" name="design-sense-select" class="quiz-checkbox" value="Own">
											<img src="/Quiz – Nooneen Design_files/Own.svg">
											<h3>مالك</h3>
											<div class="select-icon">
												<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>

					<!--  Needs Step 3  -->
					<div class="step needs-step-3 row">
						<div class="section-left col-md-12 col-lg-5">
							<h3 class="section-title">اين يقع سكنك</h3>
						</div>

						<div class="section-right col-md-12 col-lg-7">
							<select id="state">
								<option value="alaska">Alaska</option>
								<option value="alabama">Alabama</option>
								<option value="arkansas">Arkansas</option>
								<option value="american-samoa">American Samoa</option>
								<option value="arizona">Arizona</option>
								<option value="california">California</option>
								<option value="colorado">Colorado</option>
								<option value="connecticut">Connecticut</option>
								<option value="district-of-columbia">District of Columbia</option>
								<option value="delaware">Delaware</option>
								<option value="florida">Florida</option>
								<option value="georgia">Georgia</option>
								<option value="guam">Guam</option>
								<option value="hawaii">Hawaii</option>
								<option value="iowa">Iowa</option>
								<option value="idaho">Idaho</option>
								<option value="illinois">Illinois</option>
								<option value="indiana">Indiana</option>
								<option value="kansas">Kansas</option>
								<option value="kentucky">Kentucky</option>
								<option value="louisiana">Louisiana</option>
								<option value="massachusetts">Massachusetts</option>
								<option value="maryland">Maryland</option>
								<option value="maine">Maine</option>
								<option value="michigan">Michigan</option>
								<option value="minnesota">Minnesota</option>
								<option value="missouri">Missouri</option>
								<option value="mississippi">Mississippi</option>
								<option value="montana">Montana</option>
								<option value="north-Carolina">North Carolina</option>
								<option value="north-Dakota">North Dakota</option>
								<option value="nebraska">Nebraska</option>
								<option value="new-hampshire">New Hampshire</option>
								<option value="new-jersey">New Jersey</option>
								<option value="new-mexico">New Mexico</option>
								<option value="nevada">Nevada</option>
								<option value="new-york">New York</option>
								<option value="ohio">Ohio</option>
								<option value="oklahoma">Oklahoma</option>
								<option value="oregon">Oregon</option>
								<option value="pennsylvania">Pennsylvania</option>
								<option value="puerto-Rico">Puerto Rico</option>
								<option value="rhode-island">Rhode Island</option>
								<option value="south-carolina">South Carolina</option>
								<option value="south-dakota">South Dakota</option>
								<option value="tennessee">Tennessee</option>
								<option value="texas">Texas</option>
								<option value="utah">Utah</option>
								<option value="virginia">Virginia</option>
								<option value="virgin-Islands">Virgin Islands</option>
								<option value="vermont">Vermont</option>
								<option value="washington">Washington</option>
								<option value="wisconsin">Wisconsin</option>
								<option value="west-virginia">West Virginia</option>
								<option value="wyoming">Wyoming</option>

							</select>
							<button class="btn-black btn-continue" value="Let&#39;s Get Started">اكمل</button>
						</div>
					</div>

					<!--  Needs Step 4  -->
					<div class="step needs-step-4 row">
						<div class="section-left col-md-12 col-lg-5">
							<h3 class="section-title">اخبرنا بحال المساحه التي نتحدث عنها ؟</h3>
						</div>

						<div class="section-right col-md-12 col-lg-7">
							<div class="space-situation row round-checkbox">
								<div class="col-md-4 col-lg-4">
									<div class="item">
										<div class="item-inner">
											<input type="checkbox" name="design-sense-select" class="quiz-checkbox" value="BlankSpace">
											<img src="/Quiz – Nooneen Design_files/BlankSpace.svg">
											<h3>فارغه تماما</h3>
											<div class="select-icon">
												<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
											</div>
										</div>
									</div>
								</div>

								<div class="col-md-4 col-lg-4">
									<div class="item">
										<div class="item-inner">
											<input type="checkbox" name="design-sense-select" class="quiz-checkbox" value="PartwayThere">
											<img src="/Quiz – Nooneen Design_files/PartwayThere.svg">
											<h3>قيد الانشاء</h3>
											<div class="select-icon">
												<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
											</div>
										</div>
									</div>
								</div>

								<div class="col-md-4 col-lg-4">
									<div class="item">
										<div class="item-inner">
											<input type="checkbox" name="design-sense-select" class="quiz-checkbox" value="JustNeedsLove">
											<img src="/Quiz – Nooneen Design_files/JustNeedsLove.svg">
											<h3>مملوئه ب المقتنيات</h3>
											<div class="select-icon">
												<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
											</div>
										</div>
									</div>
								</div>

							</div>
						</div>
					</div>

					<!--  Needs Step 5  -->
					<div class="step needs-step-5 row">
						<div class="section-left col-md-12 col-lg-5">
							<h3 class="section-title">متي تريد العمل علي غرفتك</h3>
						</div>

						<div class="section-right col-md-12 col-lg-7">
							<div class="time row round-checkbox">
								<div class="col-md-4 col-lg-4">
									<div class="item">
										<div class="item-inner">
											<input type="checkbox" name="design-sense-select" class="quiz-checkbox" value="ASAP">
											<img src="/Quiz – Nooneen Design_files/ASAP.svg">
											<h3>في اسرع وقت</h3>
											<div class="select-icon">
												<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
											</div>
										</div>
									</div>
								</div>

								<div class="col-md-4 col-lg-4">
									<div class="item">
										<div class="item-inner">
											<input type="checkbox" name="design-sense-select" class="quiz-checkbox" value="Soonish">
											<img src="/Quiz – Nooneen Design_files/Soonish.svg">
											<h3>قريبا</h3>
											<div class="select-icon">
												<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
											</div>
										</div>
									</div>
								</div>

								<div class="col-md-4 col-lg-4">
									<div class="item">
										<div class="item-inner">
											<input type="checkbox" name="design-sense-select" class="quiz-checkbox" value="NoRush">
											<img src="/Quiz – Nooneen Design_files/NoRush.svg">
											<h3>لست علي عجله</h3>
											<div class="select-icon">
												<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
											</div>
										</div>
									</div>
								</div>

							</div>
						</div>
					</div>

					<!--  Needs Step 6  -->
					<div class="step needs-step-6 row">
						<div class="section-left col-md-12 col-lg-5">
							<h3 class="section-title">لنتحدث عن ميزانيتك</h3>
						</div>

						<div class="section-right col-md-12 col-lg-7">
							<div class="budget row round-checkbox">
								<div class="col-md-4 col-lg-4">
									<div class="item">
										<div class="item-inner">
											<input type="checkbox" name="design-sense-select" class="quiz-checkbox" value="Thrifty">
											<img src="/Quiz – Nooneen Design_files/Thrifty.svg">
											<h3>محدوده</h3>
											<div class="select-icon">
												<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
											</div>
										</div>
									</div>
								</div>

								<div class="col-md-4 col-lg-4">
									<div class="item">
										<div class="item-inner">
											<input type="checkbox" name="design-sense-select" class="quiz-checkbox" value="MixHighLow">
											<img src="/Quiz – Nooneen Design_files/MixHiLow.svg">
											<h3>متوسطه</h3>
											<div class="select-icon">
												<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
											</div>
										</div>
									</div>
								</div>

								<div class="col-md-4 col-lg-4">
									<div class="item">
										<div class="item-inner">
											<input type="checkbox" name="design-sense-select" class="quiz-checkbox" value="OnlyTheBest">
											<img src="/Quiz – Nooneen Design_files/OnlyTheBest.svg">
											<h3>مفتوحه</h3>
											<div class="select-icon">
												<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.508 1L6.752 13.011l-4.983-4.27L1 9.638l6.076 5.208L14.538 1.58z"></path></svg>
											</div>
										</div>
									</div>
								</div>

							</div>
						</div>
					</div>



				</div>

				<div class="designer-content tab-content">
					<div class="loading-designer"></div>
					<div class="selected-designer"></div>
					<div class="related-designers"></div>
				</div>

				<div class="package-content tab-content">
					<div class="your-designer"></div>
							<div data-elementor-type="section" data-elementor-id="616" class="elementor elementor-616" data-elementor-settings="[]">
		<div class="elementor-inner">
			<div class="elementor-section-wrap">
						<section class="elementor-element elementor-element-6751c80 elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="6751c80" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div class="elementor-element elementor-element-f0cc8bf elementor-column elementor-col-50 elementor-top-column" data-id="f0cc8bf" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<section class="elementor-element elementor-element-059d59e elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-inner-section" data-id="059d59e" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div class="elementor-element elementor-element-dd3d3df elementor-column elementor-col-100 elementor-inner-column" data-id="dd3d3df" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div class="elementor-element elementor-element-91ef919 elementor-widget elementor-widget-heading" data-id="91ef919" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">havenly full</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-05d23fa elementor-widget elementor-widget-text-editor" data-id="05d23fa" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
					<div class="elementor-text-editor elementor-clearfix"><span style="text-decoration-line: line-through;">$99</span>
<h1>$79</h1>
<div style="margin: 25px 0px;"><b>Update your space or add<br>
finishing touches</b></div>
<div style="font-size:13px; lin-height:20px"><b>Havenly Mini</b> is a great way to bring magic to your home, we can revamp a blah space or add the final touches that will bring your room to life.</div></div>
				</div>
				</div>
				<div class="elementor-element elementor-element-cbcdda1 elementor-align-center elementor-widget elementor-widget-button" data-id="cbcdda1" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a href="http://watrax.com/2020/opfor/july/ali//?add-to-cart=645" class="elementor-button-link elementor-button elementor-size-sm" role="button">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">GET STARTED</span>
		</span>
					</a>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-b46e7d6 elementor-widget elementor-widget-accordion" data-id="b46e7d6" data-element_type="widget" data-widget_type="accordion.default">
				<div class="elementor-widget-container">
					<div class="elementor-accordion" role="tablist">
							<div class="elementor-accordion-item">
					<div id="elementor-tab-title-1891" class="elementor-tab-title elementor-active" data-tab="1" role="tab" aria-controls="elementor-tab-content-1891">
													<span class="elementor-accordion-icon elementor-accordion-icon-left" aria-hidden="true">
															<span class="elementor-accordion-icon-closed"><i class="fas fa-angle-down"></i></span>
								<span class="elementor-accordion-icon-opened"><i class="fas fa-angle-up"></i></span>
														</span>
												<a class="elementor-accordion-title" href="http://watrax.com/2020/opfor/july/ali/quiz/">MORE DETAILS</a>
					</div>
					<div id="elementor-tab-content-1891" class="elementor-tab-content elementor-clearfix elementor-active" data-tab="1" role="tabpanel" aria-labelledby="elementor-tab-title-1891" style="display: block;">Choose your <strong>personal Havenly Designer</strong>
<p></p>
<hr>
<p></p>
<strong>1:1</strong> with your designer via online messaging, SMS or phone calls
<p></p>
<hr>
<p></p>
<strong>3 initial ideas</strong> to collaborate on, delivered within <strong>2 days</strong>
<p></p>
<hr>
<p></p>
<strong>A final design concept</strong> with curated design picks and a <strong>shopping list</strong>
<p></p>
<hr>
<p></p>
<strong>Multiple design revisions</strong> until it’s perfect
<p></p>
<hr>
<p></p>
Access to <strong>hundreds of brands</strong> and a <strong>personal ordering team</strong></div>
				</div>
					</div>
				</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
						</div>
			</div>
		</div>
				<div class="elementor-element elementor-element-167a304 elementor-column elementor-col-50 elementor-top-column" data-id="167a304" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<section class="elementor-element elementor-element-9a456dc elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-inner-section" data-id="9a456dc" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div class="elementor-element elementor-element-79bd327 pos elementor-column elementor-col-100 elementor-inner-column" data-id="79bd327" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div class="elementor-element elementor-element-808c8ca elementor-absolute elementor-widget elementor-widget-text-editor" data-id="808c8ca" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
					<div class="elementor-text-editor elementor-clearfix"><div class="ribon">BEST MATCH</div></div>
				</div>
				</div>
				<div class="elementor-element elementor-element-8673d15 elementor-widget elementor-widget-heading" data-id="8673d15" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">havenly full</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-caedf5d elementor-widget elementor-widget-text-editor" data-id="caedf5d" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
					<div class="elementor-text-editor elementor-clearfix"><span style="text-decoration-line: line-through;">$179</span>
<h1>$129</h1>
<div style="margin:25px 0px"><b>Update your space or add<br>
finishing touches</b></div>
<div style="font-size:13px; lin-height:20px"><b>Havenly Mini</b> is a great way to bring magic to your home, we can revamp a blah space or add the final touches that will bring your room to life.</div></div>
				</div>
				</div>
				<div class="elementor-element elementor-element-199ead3 elementor-align-center elementor-widget elementor-widget-button" data-id="199ead3" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a href="http://watrax.com/2020/opfor/july/ali//?add-to-cart=646" class="elementor-button-link elementor-button elementor-size-sm" role="button">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">GET STARTED</span>
		</span>
					</a>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-4113c4f elementor-widget elementor-widget-accordion" data-id="4113c4f" data-element_type="widget" data-widget_type="accordion.default">
				<div class="elementor-widget-container">
					<div class="elementor-accordion" role="tablist">
							<div class="elementor-accordion-item">
					<div id="elementor-tab-title-6821" class="elementor-tab-title elementor-active" data-tab="1" role="tab" aria-controls="elementor-tab-content-6821">
													<span class="elementor-accordion-icon elementor-accordion-icon-left" aria-hidden="true">
															<span class="elementor-accordion-icon-closed"><i class="fas fa-angle-down"></i></span>
								<span class="elementor-accordion-icon-opened"><i class="fas fa-angle-up"></i></span>
														</span>
												<a class="elementor-accordion-title" href="http://watrax.com/2020/opfor/july/ali/quiz/">MORE DETAILS</a>
					</div>
					<div id="elementor-tab-content-6821" class="elementor-tab-content elementor-clearfix elementor-active" data-tab="1" role="tabpanel" aria-labelledby="elementor-tab-title-6821" style="display: block;">Choose your <strong>personal Havenly Designer</strong>
<p></p>
<hr>
<p></p>
<strong>1:1</strong> with your designer via online messaging, SMS or phone calls
<p></p>
<hr>
<p></p>
<strong>3 initial ideas</strong> to collaborate on, delivered within <strong>2 days</strong>
<p></p>
<hr>
<p></p>
<strong>A final design concept</strong> with curated design picks and a <strong>shopping list</strong>
<p></p>
<hr>
<p></p>
<strong>Multiple design revisions</strong> until it’s perfect
<p></p>
<hr>
<p></p>
Access to <strong>hundreds of brands</strong> and a <strong>personal ordering team</strong></div>
				</div>
					</div>
				</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
					</div>
		</div>
		</div>
						</div>
			</div>
		</div>


		<input type="hidden" name="" class="style-slug" value="">
	</div>

	</div>
				</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
						</div>
			</div>
		</div>

	</div><!-- #content -->




			</div><!-- .wf-container -->
		</div><!-- .wf-wrap -->


	</div><!-- #main -->







@endsection
