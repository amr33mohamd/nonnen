<div id="page" class="closed-mobile-header">
  <a class="skip-link screen-reader-text" href="http://watrax.com/2020/opfor/july/ali/regist/#content">Skip to content</a>

  <div class="mobile-header-space"></div>
  <div class="masthead inline-header right widgets shadow-decoration shadow-mobile-header-decoration small-mobile-menu-icon dt-parent-menu-clickable show-device-logo show-mobile-logo sticky-off fixed-masthead sticky-off" role="banner">

    <div class="top-bar full-width-line top-bar-empty top-bar-line-hide">
      <div class="top-bar-bg"></div>
      <div class="mini-widgets left-widgets"></div>
      <div class="mini-widgets right-widgets"></div>
    </div>

    <header class="header-bar" style="height: 60px; transition: all 0.3s ease 0s;">

      <div class="branding"><a class="sticky-logo" href="http://watrax.com/2020/opfor/july/ali/">
       </a>
        <div id="site-title" class="assistive-text">Nooneen Design</div>
        <div id="site-description" class="assistive-text"></div>
        <a class="" href="/"><img class=" preload-me" src="/Explore – Nooneen Design_files/Mian-logo-main.png"
            srcset="/Register – Nooneen Design_files/floationg-logo.png" width="100" height="70" sizes="144px"
            alt="Nooneen Design"><img class="mobile-logo preload-me" src="/Explore – Nooneen Design_files/Mobile-Logo.png" srcset="http://watrax.com/2020/opfor/july/ali/wp-content/uploads/2020/10/Mobile-Logo.png 72w" width="72" height="35"
            sizes="72px" alt="Nooneen Design"></a>
      </div>

      <ul id="primary-menu" class="main-nav level-arrows-on outside-item-custom-margin" role="navigation">
        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-141 first "><a href="/ar/" data-level="1"><span class="menu-item-text"><span
                class="menu-text">الرئيسيه</span></span></a>

        </li>


        <li class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-224 current_page_item menu-item-226 act"><a href="/ar/gallery" data-level="1"><span
              class="menu-item-text"><span class="menu-text">معرضنا</span></span></a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-321"><a href="/ar/shop" data-level="1"><span class="menu-item-text"><span class="menu-text">المتجر</span></span></a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-708"><a href="/ar/login" data-level="1"><span class="menu-item-text"><span class="menu-text">تسجيل الدخول</span></span></a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-711"><a href="/ar/register" data-level="1"><span class="menu-item-text"><span class="menu-text">التسجيل</span></span></a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-711"><a href="/ar/register-designer" data-level="1"><span class="menu-item-text"><span class="menu-text">انضم ك مصمم</span></span></a></li>

        <li class="menu-item wpml-ls-slot-17 wpml-ls-item wpml-ls-item-en wpml-ls-current-language wpml-ls-menu-item wpml-ls-first-item wpml-ls-last-item menu-item-type-wpml_ls_menu_item menu-item-object-wpml_ls_menu_item menu-item-wpml-ls-17-en">
          <a href="/" data-level="1"><span class="menu-item-text"><span class="menu-text"><img class="wpml-ls-flag" src="/Explore – Nooneen Design_files/en.png" alt="English"></span></span></a></li>
      </ul>

    </header>


  </div>
  <div class="header-space sticky-space-off" style="height: 90px;"></div>
  <div class="dt-mobile-header mobile-menu-show-divider dt-parent-menu-clickable">
    <div class="mobile-header-scrollbar-wrap">
      <div class="dt-close-mobile-menu-icon">
        <div class="close-line-wrap"><span class="close-line"></span><span class="close-line"></span><span class="close-line"></span></div>
      </div>
      <ul id="mobile-menu" class="mobile-main-nav" role="navigation">
        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-141 first has-children"><a href="/ar" data-level="1"><span class="menu-item-text"><span
                class="menu-text">How Its Work</span></span></a>

        </li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-601 has-children"><a href="http://watrax.com/2020/opfor/july/ali/designer/" data-level="1"><span class="menu-item-text"><span
                class="menu-text">Designer</span></span></a><i class="next-level-button"></i>
          <ul class="sub-nav level-arrows-on">
            <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-665 first"><a href="http://watrax.com/2020/opfor/july/ali/regist/#" data-level="2"><span class="menu-item-text"><span
                    class="menu-text">Classic</span></span></a></li>
            <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-666"><a href="http://watrax.com/2020/opfor/july/ali/regist/#" data-level="2"><span class="menu-item-text"><span class="menu-text">Elite</span></span></a></li>
          </ul>
        </li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-223 has-children"><a href="http://watrax.com/2020/opfor/july/ali/stories/" data-level="1"><span class="menu-item-text"><span
                class="menu-text">Stories</span></span></a><i class="next-level-button"></i>
          <ul class="sub-nav level-arrows-on">
            <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-668 first"><a href="http://watrax.com/2020/opfor/july/ali/reviews/" data-level="2"><span class="menu-item-text"><span
                    class="menu-text">Reviews</span></span></a></li>
          </ul>
        </li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-226"><a href="/ar/designs" data-level="1"><span class="menu-item-text"><span class="menu-text">Our Gallery</span></span></a>
        </li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-321"><a href="/ar/shop" data-level="1"><span class="menu-item-text"><span class="menu-text">Shop</span></span></a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-708"><a href="/ar/login" data-level="1"><span class="menu-item-text"><span class="menu-text">Login</span></span></a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-629 current_page_item menu-item-711 act"><a href="/ar/register" data-level="1"><span
              class="menu-item-text"><span class="menu-text">Register</span></span></a></li>
              <li class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-629 current_page_item menu-item-711 act"><a href="/ar/register" data-level="1"><span
                    class="menu-item-text"><span class="menu-text">Register Desiner</span></span></a></li>
        <li class="menu-item wpml-ls-slot-17 wpml-ls-item wpml-ls-item-en wpml-ls-current-language wpml-ls-menu-item wpml-ls-first-item wpml-ls-last-item menu-item-type-wpml_ls_menu_item menu-item-object-wpml_ls_menu_item menu-item-wpml-ls-17-en">
          <a href="/" data-level="1"><span class="menu-item-text"><span class="menu-text"><img class="wpml-ls-flag" src="/Register – Nooneen Design_files/en.png" alt="English"></span></span></a></li>
      </ul>
      <div class="mobile-mini-widgets-in-menu first-switch-no-widgets"><a href="http://watrax.com/2020/opfor/july/ali/quiz/"
          class="microwidget-btn mini-button header-elements-button-1 show-on-desktop near-logo-first-switch in-menu-second-switch microwidget-btn-bg-on microwidget-btn-hover-bg-on disable-animation-bg border-off hover-border-off btn-icon-align-right first last hide-on-desktop hide-on-first-switch show-on-second-switch"><span>Get
            Started</span></a></div>
    </div>
  </div>
