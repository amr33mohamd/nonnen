

		<!-- !Footer -->
		<footer id="footer" class="footer solid-bg elementor-footer empty-footer">


			<div class="wf-wrap">
				<div class="wf-container-footer">
					<div class="wf-container">
						<div data-elementor-type="footer" data-elementor-id="120" class="elementor elementor-120 elementor-location-footer" data-elementor-settings="[]">
							<div class="elementor-inner">
								<div class="elementor-section-wrap">
									<section class="elementor-element elementor-element-fe3040e elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="fe3040e"
										data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
										<div class="elementor-container elementor-column-gap-default">
											<div class="elementor-row">
												<div class="elementor-element elementor-element-d2c0c43 elementor-column elementor-col-25 elementor-top-column" data-id="d2c0c43" data-element_type="column">
													<div class="elementor-column-wrap  elementor-element-populated">
														<div class="elementor-widget-wrap">
															<div class="elementor-element elementor-element-6646ece elementor-widget elementor-widget-image" data-id="6646ece" data-element_type="widget" data-widget_type="image.default">
																<div class="elementor-widget-container">
																	<div class="" >
																		<img width="103" height="50" src="/Register – Nooneen Design_files/floationg-logo.png" class="attachment-full size-full" alt="" style="float:right"> </div>
																</div>
															</div>
															<div class="elementor-element elementor-element-2173c19 elementor-widget elementor-widget-text-editor" data-id="2173c19" data-element_type="widget" data-widget_type="text-editor.default">
																<div class="elementor-widget-container">
																	<div class="elementor-text-editor elementor-clearfix">
																		<p>تأسس فريق الاخوين نونين سنه ٢٠٢٠ انطلاقا من ايماننا باهميه التصميم الداخلي باعتباره الوسيله التي شانها ضمان جو من السلام و الاسترخاء في كل مكان</p>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div class="elementor-element elementor-element-aa30810 elementor-column elementor-col-25 elementor-top-column" data-id="aa30810" data-element_type="column">
													<div class="elementor-column-wrap  elementor-element-populated">
														<div class="elementor-widget-wrap">
															<div class="elementor-element elementor-element-3bdb614 elementor-widget elementor-widget-heading" data-id="3bdb614" data-element_type="widget" data-widget_type="heading.default">
																<div class="elementor-widget-container">
																	<h2 class="elementor-heading-title elementor-size-default" style="text-align:right;padding:8px">القائمه</h2>
																</div>
															</div>
															<div
																class="elementor-element elementor-element-9648500 elementor-nav-menu--indicator-chevron elementor-nav-menu--dropdown-tablet elementor-nav-menu__text-align-aside elementor-nav-menu--toggle elementor-nav-menu--burger elementor-widget elementor-widget-nav-menu"
																data-id="9648500" data-element_type="widget" data-settings="{&quot;layout&quot;:&quot;vertical&quot;,&quot;toggle&quot;:&quot;burger&quot;}" data-widget_type="nav-menu.default">
																<div class="elementor-widget-container">
																	<nav role="navigation" class="elementor-nav-menu--main elementor-nav-menu__container elementor-nav-menu--layout-vertical e--pointer-underline e--animation-fade">
																		<ul id="menu-1-9648500" class="elementor-nav-menu sm-vertical" data-smartmenus-id="16091843013776643">
																			<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-767"><a href="/ar" class="elementor-item">الرئيسيه</a></li>
																			<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-769"><a href="/ar/galery" class="elementor-item">معرضنا</a></li>
																		</ul>
																	</nav>
																	<div class="elementor-menu-toggle" role="button" tabindex="0" aria-label="Menu Toggle" aria-expanded="false" style="text-align:right;padding:8px">
																		<i class="eicon-menu-bar" aria-hidden="true"></i>
																		<span class="elementor-screen-only">القائمه</span>
																	</div>
																	<nav class="elementor-nav-menu--dropdown elementor-nav-menu__container" role="navigation" aria-hidden="true">
																		<ul id="menu-2-9648500" class="elementor-nav-menu sm-vertical" data-smartmenus-id="16091843013788586">
																			<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-767"><a href="/ar" class="elementor-item">الرئيسيه</a></li>
																			<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-769"><a href="/ar/gallery" class="elementor-item"> معرضنا</a></li>
																		</ul>
																	</nav>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div class="elementor-element elementor-element-3cccf98 elementor-column elementor-col-25 elementor-top-column" data-id="3cccf98" data-element_type="column">
													<div class="elementor-column-wrap  elementor-element-populated">
														<div class="elementor-widget-wrap">
															<div class="elementor-element elementor-element-4264b15 elementor-widget elementor-widget-heading" data-id="4264b15" data-element_type="widget" data-widget_type="heading.default">
																<div class="elementor-widget-container">
																	<h2 class="elementor-heading-title elementor-size-default" style="text-align:right;padding:8px">معلومات التواصل</h2>
																</div>
															</div>
															<div class="elementor-element elementor-element-0456165 elementor-position-left elementor-view-default elementor-vertical-align-top elementor-widget elementor-widget-icon-box" data-id="0456165" data-element_type="widget"
																data-widget_type="icon-box.default">
																<div class="elementor-widget-container">
																	<div class="elementor-icon-box-wrapper">
																		<div class="elementor-icon-box-icon">
																			<span class="elementor-icon elementor-animation-">
																				<i aria-hidden="true" class="fas fa-home"></i> </span>
																		</div>
																		<div class="elementor-icon-box-content">
																			<h4 class="elementor-icon-box-title" style="text-align:right;padding:8px">
																				<span>العنوان</span>
																			</h4>
																			<p class="elementor-icon-box-description" style="text-align:right;padding:8px">السعوديه</p>
																		</div>
																	</div>
																</div>
															</div>
															<div style="text-align:right" class="elementor-element elementor-element-4fc0708 elementor-position-left elementor-view-default elementor-vertical-align-top elementor-widget elementor-widget-icon-box" data-id="4fc0708" data-element_type="widget"
																data-widget_type="icon-box.default">
																<div class="elementor-widget-container">
																	<div class="elementor-icon-box-wrapper">
																		<div class="elementor-icon-box-icon">
																			<span class="elementor-icon elementor-animation-">
																				<i aria-hidden="true" class="fas fa-phone-volume"></i> </span>
																		</div>
																		<div class="elementor-icon-box-content">
																			<h4 class="elementor-icon-box-title" style="text-align:right;padding:8px">
																				<span>رقم الهاتف</span>
																			</h4>
																			<p class="elementor-icon-box-description" style="text-align:right;padding:8px">+123 456 789</p>
																		</div>
																	</div>
																</div>
															</div>
															<div class="elementor-element elementor-element-96e333c elementor-position-left elementor-view-default elementor-vertical-align-top elementor-widget elementor-widget-icon-box" data-id="96e333c" data-element_type="widget"
																data-widget_type="icon-box.default">
																<div class="elementor-widget-container">
																	<div class="elementor-icon-box-wrapper">
																		<div class="elementor-icon-box-icon">
																			<span class="elementor-icon elementor-animation-">
																				<i aria-hidden="true" class="fas fa-mail-bulk"></i> </span>
																		</div>
																		<div class="elementor-icon-box-content">
																			<h4 class="elementor-icon-box-title" style="text-align:right;padding:8px">
																				<span >البريد الالكتروني</span>
																			</h4>
																			<p class="elementor-icon-box-description" style="text-align:right;padding:8px">example@example.com</p>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div class="elementor-element elementor-element-fac5d70 elementor-column elementor-col-25 elementor-top-column" data-id="fac5d70" data-element_type="column">
													<div class="elementor-column-wrap  elementor-element-populated">
														<div class="elementor-widget-wrap">
															<div class="elementor-element elementor-element-2e667d9 elementor-widget elementor-widget-heading" data-id="2e667d9" data-element_type="widget" data-widget_type="heading.default">
																<div class="elementor-widget-container">
																	<h2 class="elementor-heading-title elementor-size-default" style="text-align:right;padding:8px">الاشتراك </h2>
																</div>
															</div>
															<div class="elementor-element elementor-element-b72c81e elementor-button-align-stretch elementor-widget elementor-widget-form" data-id="b72c81e" data-element_type="widget"
																data-settings="{&quot;step_next_label&quot;:&quot;Next&quot;,&quot;step_previous_label&quot;:&quot;Previous&quot;,&quot;button_width&quot;:&quot;100&quot;,&quot;step_type&quot;:&quot;number_text&quot;,&quot;step_icon_shape&quot;:&quot;circle&quot;}"
																data-widget_type="form.default">
																<div class="elementor-widget-container">
																	<form class="elementor-form" method="post" name="New Form">
																		<input type="hidden" name="post_id" value="120">
																		<input type="hidden" name="form_id" value="b72c81e">

																		<input type="hidden" name="queried_id" value="629">

																		<div class="elementor-form-fields-wrapper elementor-labels-">
																			<div class="elementor-field-type-email elementor-field-group elementor-column elementor-field-group-email elementor-col-100 elementor-field-required">
																				<label for="form-field-email" class="elementor-field-label elementor-screen-only">البريد الالكتروني</label><input size="1" type="email" name="form_fields[email]" id="form-field-email"
																					class="elementor-field elementor-size-md  elementor-field-textual" placeholder="Enter Your Email" required="required" aria-required="true"> </div>
																			<div class="elementor-field-group elementor-column elementor-field-type-submit elementor-col-100 e-form__buttons">
																				<button type="submit" class="elementor-button elementor-size-sm">
																					<span>
																						<span class=" elementor-button-icon">
																						</span>
																						<span class="elementor-button-text">ارسال</span>
																					</span>
																				</button>
																			</div>
																		</div>
																	</form>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</section>
									<footer
										class="elementor-element elementor-element-5f360e62 elementor-section-height-min-height elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-items-middle elementor-section elementor-top-section"
										data-id="5f360e62" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
										<div class="elementor-container elementor-column-gap-default">
											<div class="elementor-row">
												<div class="elementor-element elementor-element-145640fe elementor-column elementor-col-100 elementor-top-column" data-id="145640fe" data-element_type="column">
													<div class="elementor-column-wrap  elementor-element-populated">
														<div class="elementor-widget-wrap">
															<div class="elementor-element elementor-element-149e9b41 elementor-widget elementor-widget-heading" data-id="149e9b41" data-element_type="widget" data-widget_type="heading.default">
																<div class="elementor-widget-container">
																	<h3 class="elementor-heading-title elementor-size-default">Copyright © 2020 Nooneen Design | Powered by </h3>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</footer>
								</div>
							</div>
						</div>
					</div><!-- .wf-container -->
				</div><!-- .wf-container-footer -->
			</div><!-- .wf-wrap -->


		</footer><!-- #footer -->


		<a href="http://watrax.com/2020/opfor/july/ali/regist/#" class="scroll-top"><span class="screen-reader-text">Go to Top</span></a>

	</div><!-- #page -->


	<div id="fb-root" class=" fb_reset">
		<div style="position: absolute; top: -10000px; width: 0px; height: 0px;">
			<div></div>
		</div>
		<div class="fb-customerchat fb_invisible_flow fb_iframe_widget" attribution="wordpress" attribution_version="1.7" page_id="102395284936848" fb-xfbml-state="rendered"
			fb-iframe-plugin-query="app_id=&amp;attribution=wordpress&amp;attribution_version=1.7&amp;container_width=0&amp;local_state=%7B%22v%22%3A0%2C%22path%22%3A2%2C%22chatState%22%3A1%2C%22visibility%22%3A%22hidden%22%2C%22showUpgradePrompt%22%3A%22not_shown%22%7D&amp;locale=en_US&amp;page_id=102395284936848&amp;request_time=1609184301427&amp;sdk=joey">
			<span style="vertical-align: bottom; width: 0px; height: 0px;"><iframe name="fca54140c65968" width="1000px" height="1000px" title="" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" allow="encrypted-media"
					src="/Register – Nooneen Design_files/customerchat.html"
					style="padding: 0px; position: fixed; z-index: 2147483646; border-radius: 16px; top: auto; width: 399px; max-height: 0px; background: none; bottom: 85px; right: 4px; margin-right: 12px; visibility: visible; min-height: 0px;"
					class=" fb_customer_chat_bounce_out_v2" data-testid="dialog_iframe"></iframe></span></div>
		<div class="fb_dialog  fb_dialog_advanced" style="overflow: visible; z-index: 2147483644;">
			<div class="fb_dialog_content"><iframe name="blank_fca54140c65968" width="60px" tabindex="-1" data-testid="bubble_iframe" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" allow="encrypted-media"
					src="/Register – Nooneen Design_files/bubble.html"
					style="margin: 0px 12px; padding: 0px; position: fixed; z-index: 2147483644; bottom: 24px; top: auto; height: 60px; width: 60px; border-radius: 29px; box-shadow: rgba(0, 0, 0, 0.15) 0px 4px 12px 0px; background: none; display: block; right: 12px;"></iframe><iframe
					name="unread_fca54140c65968" tabindex="-1" data-testid="unread_iframe" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" allow="encrypted-media" src="/Register – Nooneen Design_files/bubble(1).html"
					style="bottom: 68px; position: fixed; width: 20px; height: 24px; z-index: 2147483645; border-radius: 4pt; background: none; right: 22px;"></iframe></div>
		</div>
	</div>


	<script type="text/javascript">
		var c = document.body.className;
		c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
		document.body.className = c;
	</script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/main.min.js"></script>
	<script type="text/javascript">
		/* <![CDATA[ */
		var wpcf7 = {
			"apiSettings": {
				"root": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-json\/contact-form-7\/v1",
				"namespace": "contact-form-7\/v1"
			}
		};
		/* ]]> */
	</script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/scripts(1).js"></script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/jquery.blockUI.min.js"></script>
	<script type="text/javascript">
		/* <![CDATA[ */
		var wc_add_to_cart_params = {
			"ajax_url": "\/2020\/opfor\/july\/ali\/wp-admin\/admin-ajax.php",
			"wc_ajax_url": "\/2020\/opfor\/july\/ali\/?wc-ajax=%%endpoint%%",
			"i18n_view_cart": "View cart",
			"cart_url": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/cart\/",
			"is_cart": "",
			"cart_redirect_after_add": "yes"
		};
		/* ]]> */
	</script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/add-to-cart.min.js"></script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/js.cookie.min.js"></script>
	<script type="text/javascript">
		/* <![CDATA[ */
		var woocommerce_params = {
			"ajax_url": "\/2020\/opfor\/july\/ali\/wp-admin\/admin-ajax.php",
			"wc_ajax_url": "\/2020\/opfor\/july\/ali\/?wc-ajax=%%endpoint%%"
		};
		/* ]]> */
	</script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/woocommerce.min.js"></script>
	<script type="text/javascript">
		/* <![CDATA[ */
		var wc_cart_fragments_params = {
			"ajax_url": "\/2020\/opfor\/july\/ali\/wp-admin\/admin-ajax.php",
			"wc_ajax_url": "\/2020\/opfor\/july\/ali\/?wc-ajax=%%endpoint%%",
			"cart_hash_key": "wc_cart_hash_cf278bc9cde494c8800f49904f9839a2",
			"fragment_name": "wc_fragments_cf278bc9cde494c8800f49904f9839a2",
			"request_timeout": "5000"
		};
		/* ]]> */
	</script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/cart-fragments.min.js"></script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/wp-embed.min.js"></script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/jquery.smartmenus.min.js"></script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/frontend-modules.min.js"></script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/jquery.sticky.min.js"></script>
	<script type="text/javascript">
		var ElementorProFrontendConfig = {
			"ajaxurl": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-admin\/admin-ajax.php",
			"nonce": "c565137372",
			"i18n": {
				"toc_no_headings_found": "No headings were found on this page."
			},
			"shareButtonsNetworks": {
				"facebook": {
					"title": "Facebook",
					"has_counter": true
				},
				"twitter": {
					"title": "Twitter"
				},
				"google": {
					"title": "Google+",
					"has_counter": true
				},
				"linkedin": {
					"title": "LinkedIn",
					"has_counter": true
				},
				"pinterest": {
					"title": "Pinterest",
					"has_counter": true
				},
				"reddit": {
					"title": "Reddit",
					"has_counter": true
				},
				"vk": {
					"title": "VK",
					"has_counter": true
				},
				"odnoklassniki": {
					"title": "OK",
					"has_counter": true
				},
				"tumblr": {
					"title": "Tumblr"
				},
				"delicious": {
					"title": "Delicious"
				},
				"digg": {
					"title": "Digg"
				},
				"skype": {
					"title": "Skype"
				},
				"stumbleupon": {
					"title": "StumbleUpon",
					"has_counter": true
				},
				"mix": {
					"title": "Mix"
				},
				"telegram": {
					"title": "Telegram"
				},
				"pocket": {
					"title": "Pocket",
					"has_counter": true
				},
				"xing": {
					"title": "XING",
					"has_counter": true
				},
				"whatsapp": {
					"title": "WhatsApp"
				},
				"email": {
					"title": "Email"
				},
				"print": {
					"title": "Print"
				}
			},
			"menu_cart": {
				"cart_page_url": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/cart\/",
				"checkout_page_url": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/checkout\/"
			},
			"facebook_sdk": {
				"lang": "en_US",
				"app_id": ""
			},
			"lottie": {
				"defaultAnimationUrl": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json"
			}
		};
	</script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/frontend.min.js"></script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/position.min.js"></script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/dialog.min.js"></script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/waypoints.min.js"></script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/swiper.min.js"></script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/share-link.min.js"></script>
	<script type="text/javascript">
		var elementorFrontendConfig = {
			"environmentMode": {
				"edit": false,
				"wpPreview": false
			},
			"i18n": {
				"shareOnFacebook": "Share on Facebook",
				"shareOnTwitter": "Share on Twitter",
				"pinIt": "Pin it",
				"downloadImage": "Download image"
			},
			"is_rtl": false,
			"breakpoints": {
				"xs": 0,
				"sm": 480,
				"md": 768,
				"lg": 1025,
				"xl": 1440,
				"xxl": 1600
			},
			"version": "2.9.14",
			"urls": {
				"assets": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/plugins\/elementor\/assets\/"
			},
			"settings": {
				"page": [],
				"general": {
					"elementor_global_image_lightbox": "yes",
					"elementor_lightbox_enable_counter": "yes",
					"elementor_lightbox_enable_fullscreen": "yes",
					"elementor_lightbox_enable_zoom": "yes",
					"elementor_lightbox_enable_share": "yes",
					"elementor_lightbox_title_src": "title",
					"elementor_lightbox_description_src": "description"
				},
				"editorPreferences": []
			},
			"post": {
				"id": 629,
				"title": "Register%20%E2%80%93%20Nooneen%20Design",
				"excerpt": "",
				"featuredImage": false
			}
		};
	</script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/frontend.min(2).js"></script><span id="elementor-device-mode" class="elementor-screen-only"></span>
	<div class="pafe-break-point" data-pafe-break-point-md="768" data-pafe-break-point-lg="1025" data-pafe-ajax-url="http://watrax.com/2020/opfor/july/ali/wp-admin/admin-ajax.php"></div>
	<div data-pafe-form-builder-tinymce-upload="http://watrax.com/2020/opfor/july/ali/wp-content/plugins/piotnet-addons-for-elementor-pro/inc/tinymce/tinymce-upload.php"></div>
	<div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="pswp__bg"></div>
		<div class="pswp__scroll-wrap">
			<div class="pswp__container">
				<div class="pswp__item"></div>
				<div class="pswp__item"></div>
				<div class="pswp__item"></div>
			</div>
			<div class="pswp__ui pswp__ui--hidden">
				<div class="pswp__top-bar">
					<div class="pswp__counter"></div>
					<button class="pswp__button pswp__button--close" title="Close (Esc)" aria-label="Close (Esc)"></button>
					<button class="pswp__button pswp__button--share" title="Share" aria-label="Share"></button>
					<button class="pswp__button pswp__button--fs" title="Toggle fullscreen" aria-label="Toggle fullscreen"></button>
					<button class="pswp__button pswp__button--zoom" title="Zoom in/out" aria-label="Zoom in/out"></button>
					<div class="pswp__preloader">
						<div class="pswp__preloader__icn">
							<div class="pswp__preloader__cut">
								<div class="pswp__preloader__donut"></div>
							</div>
						</div>
					</div>
				</div>
				<div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
					<div class="pswp__share-tooltip"></div>
				</div>
				<button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)" aria-label="Previous (arrow left)">
				</button>
				<button class="pswp__button pswp__button--arrow--right" title="Next (arrow right)" aria-label="Next (arrow right)">
				</button>
				<div class="pswp__caption">
					<div class="pswp__caption__center"></div>
				</div>
			</div>
		</div>
	</div>


	<div class="mobile-sticky-header-overlay"></div>
	<div class="mobile-sticky-sidebar-overlay"></div>
	<div class="iso-preloader dt-posts-preload dt-posts-preload-active" style="display: none;">
		<div class="dt-posts-preload-activity"></div>
	</div>
