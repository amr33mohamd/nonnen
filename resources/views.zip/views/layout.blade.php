<!DOCTYPE html>
<!-- saved from url=(0045)http://watrax.com/2020/opfor/july/ali/regist/ -->
<html lang="en-US" class="js supports no-touchevents no-forcetouch cssanimations no-cssgridlegacy cssgrid cssfilters csstransforms csstransforms3d csstransitions mobile-false not-iOS" style="">
<!--<![endif]-->

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<link rel="stylesheet" href="	https://7basis.com/wp-content/themes/dt-the7/fonts/icomoon-the7-font/icomoon-the7-font.css">

	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" rel="stylesheet">

	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
	<meta name="theme-color" content="#ffe0e0">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<script id="facebook-jssdk" src="/Register – Nooneen Design_files/xfbml.customerchat.js"></script>
	<script type="text/javascript">
		if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
			var originalAddEventListener = EventTarget.prototype.addEventListener,
				oldWidth = window.innerWidth;

			EventTarget.prototype.addEventListener = function(eventName, eventHandler, useCapture) {
				if (eventName === "resize") {
					originalAddEventListener.call(this, eventName, function(event) {
						if (oldWidth === window.innerWidth) {
							return;
						} else if (oldWidth !== window.innerWidth) {
							oldWidth = window.innerWidth;
						}
						if (eventHandler.handleEvent) {
							eventHandler.handleEvent.call(this, event);
						} else {
							eventHandler.call(this, event);
						};
					}, useCapture);
				} else {
					originalAddEventListener.call(this, eventName, eventHandler, useCapture);
				};
			};
		};
	</script>
	<title>Register – Nooneen Design</title>
	<meta name="robots" content="noindex,nofollow">
	<link rel="alternate" hreflang="en" href="http://watrax.com/2020/opfor/july/ali/regist/">
	<link rel="dns-prefetch" href="http://cdnjs.cloudflare.com/">
	<link rel="dns-prefetch" href="http://kit-pro.fontawesome.com/">
	<link rel="dns-prefetch" href="http://fonts.googleapis.com/">
	<link rel="dns-prefetch" href="http://s.w.org/">
	<link rel="alternate" type="application/rss+xml" title="Nooneen Design » Feed" href="http://watrax.com/2020/opfor/july/ali/feed/">
	<link rel="alternate" type="application/rss+xml" title="Nooneen Design » Comments Feed" href="http://watrax.com/2020/opfor/july/ali/comments/feed/">
	<script type="text/javascript">
		window._wpemojiSettings = {
			"baseUrl": "https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/",
			"ext": ".png",
			"svgUrl": "https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/",
			"svgExt": ".svg",
			"source": {
				"concatemoji": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.4.4"
			}
		};
		/*! This file is auto-generated */
		! function(e, a, t) {
			var r, n, o, i, p = a.createElement("canvas"),
				s = p.getContext && p.getContext("2d");

			function c(e, t) {
				var a = String.fromCharCode;
				s.clearRect(0, 0, p.width, p.height), s.fillText(a.apply(this, e), 0, 0);
				var r = p.toDataURL();
				return s.clearRect(0, 0, p.width, p.height), s.fillText(a.apply(this, t), 0, 0), r === p.toDataURL()
			}

			function l(e) {
				if (!s || !s.fillText) return !1;
				switch (s.textBaseline = "top", s.font = "600 32px Arial", e) {
					case "flag":
						return !c([127987, 65039, 8205, 9895, 65039], [127987, 65039, 8203, 9895, 65039]) && (!c([55356, 56826, 55356, 56819], [55356, 56826, 8203, 55356, 56819]) && !c([55356, 57332, 56128, 56423, 56128, 56418, 56128, 56421, 56128, 56430, 56128,
							56423, 56128, 56447
						], [55356, 57332, 8203, 56128, 56423, 8203, 56128, 56418, 8203, 56128, 56421, 8203, 56128, 56430, 8203, 56128, 56423, 8203, 56128, 56447]));
					case "emoji":
						return !c([55357, 56424, 55356, 57342, 8205, 55358, 56605, 8205, 55357, 56424, 55356, 57340], [55357, 56424, 55356, 57342, 8203, 55358, 56605, 8203, 55357, 56424, 55356, 57340])
				}
				return !1
			}

			function d(e) {
				var t = a.createElement("script");
				t.src = e, t.defer = t.type = "text/javascript", a.getElementsByTagName("head")[0].appendChild(t)
			}
			for (i = Array("flag", "emoji"), t.supports = {
					everything: !0,
					everythingExceptFlag: !0
				}, o = 0; o < i.length; o++) t.supports[i[o]] = l(i[o]), t.supports.everything = t.supports.everything && t.supports[i[o]], "flag" !== i[o] && (t.supports.everythingExceptFlag = t.supports.everythingExceptFlag && t.supports[i[o]]);
			t.supports.everythingExceptFlag = t.supports.everythingExceptFlag && !t.supports.flag, t.DOMReady = !1, t.readyCallback = function() {
				t.DOMReady = !0
			}, t.supports.everything || (n = function() {
				t.readyCallback()
			}, a.addEventListener ? (a.addEventListener("DOMContentLoaded", n, !1), e.addEventListener("load", n, !1)) : (e.attachEvent("onload", n), a.attachEvent("onreadystatechange", function() {
				"complete" === a.readyState && t.readyCallback()
			})), (r = t.source || {}).concatemoji ? d(r.concatemoji) : r.wpemoji && r.twemoji && (d(r.twemoji), d(r.wpemoji)))
		}(window, document, window._wpemojiSettings);
	</script>
	<script src="/Register – Nooneen Design_files/wp-emoji-release.min.js" type="text/javascript" defer=""></script>
	<style type="text/css">
		img.wp-smiley,
		img.emoji {
			display: inline !important;
			border: none !important;
			box-shadow: none !important;
			height: 1em !important;
			width: 1em !important;
			margin: 0 .07em !important;
			vertical-align: -0.1em !important;
			background: none !important;
			padding: 0 !important;
		}
	</style>
	<link rel="stylesheet" id="wp-block-library-css" href="/Register – Nooneen Design_files/style.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="wp-block-library-theme-css" href="/Register – Nooneen Design_files/theme.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="wc-block-vendors-style-css" href="/Register – Nooneen Design_files/vendors-style.css" type="text/css" media="all">
	<link rel="stylesheet" id="wc-block-style-css" href="/Register – Nooneen Design_files/style.css" type="text/css" media="all">
	<link rel="stylesheet" id="contact-form-7-css" href="/Register – Nooneen Design_files/styles.css" type="text/css" media="all">
	<link rel="stylesheet" id="dq-fontawesome-css" href="/Register – Nooneen Design_files/pro.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="dq-slick-css-css" href="/Register – Nooneen Design_files/slick.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="elementor-post-10-css" href="/Register – Nooneen Design_files/post-10.css" type="text/css" media="all">

	<link rel="stylesheet" id="dq-slick-theme-css-css" href="/Register – Nooneen Design_files/slick-theme.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="dq-style-css" href="/Register – Nooneen Design_files/style(1).css" type="text/css" media="all">
	<link rel="stylesheet" id="dq-responsive-style-css" href="/Register – Nooneen Design_files/responsive.css" type="text/css" media="all">
	<link rel="stylesheet" id="pafe-extension-style-css" href="/Register – Nooneen Design_files/extension.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="pafe-woocommerce-sales-funnels-style-css" href="/Register – Nooneen Design_files/woocommerce-sales-funnels.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="rs-plugin-settings-css" href="/Register – Nooneen Design_files/rs6.css" type="text/css" media="all">
	<style id="rs-plugin-settings-inline-css" type="text/css">
		#rs-demo-id {}
	</style>
	<style id="woocommerce-inline-inline-css" type="text/css">
		.woocommerce form .form-row .required {
			visibility: visible;
		}
	</style>
	<link rel="stylesheet" id="wpml-legacy-horizontal-list-0-css" href="/Register – Nooneen Design_files/style(2).css" type="text/css" media="all">
	<link rel="stylesheet" id="wpml-menu-item-0-css" href="/Register – Nooneen Design_files/style(3).css" type="text/css" media="all">
	<link rel="stylesheet" id="elementor-icons-css" href="/Register – Nooneen Design_files/elementor-icons.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="elementor-animations-css" href="/Register – Nooneen Design_files/animations.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="elementor-frontend-css" href="/Register – Nooneen Design_files/frontend.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="elementor-pro-css" href="/Register – Nooneen Design_files/frontend.min(1).css" type="text/css" media="all">
	<link rel="stylesheet" id="premium-pro-css" href="/Register – Nooneen Design_files/premium-addons.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="elementor-global-css" href="/Register – Nooneen Design_files/global.css" type="text/css" media="all">
	<link rel="stylesheet" id="elementor-post-573-css" href="/Register – Nooneen Design_files/post-573.css" type="text/css" media="all">
	<link rel="stylesheet" id="elementor-post-559-css" href="/Register – Nooneen Design_files/post-559.css" type="text/css" media="all">
	<link rel="stylesheet" id="elementor-post-616-css" href="/Register – Nooneen Design_files/post-616.css" type="text/css" media="all">
	<link rel="stylesheet" id="elementor-post-120-css" href="/Register – Nooneen Design_files/post-120.css" type="text/css" media="all">
	<link rel="stylesheet" id="dt-web-fonts-css" href="/Register – Nooneen Design_files/css" type="text/css" media="all">
	<link rel="stylesheet" id="dt-main-css" href="/Register – Nooneen Design_files/main.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="the7-font-css" href="/Register – Nooneen Design_files/icomoon-the7-font.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="the7-core-css" href="/Register – Nooneen Design_files/post-type.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="dt-custom-css" href="/Register – Nooneen Design_files/custom.css" type="text/css" media="all">
	<link rel="stylesheet" id="wc-dt-custom-css" href="/Register – Nooneen Design_files/wc-dt-custom.css" type="text/css" media="all">
	<link rel="stylesheet" id="dt-media-css" href="/Register – Nooneen Design_files/media.css" type="text/css" media="all">
	<link rel="stylesheet" id="the7-mega-menu-css" href="/Register – Nooneen Design_files/mega-menu.css" type="text/css" media="all">
	<link rel="stylesheet" id="the7-elements-css" href="/Register – Nooneen Design_files/post-type-dynamic.css" type="text/css" media="all">
	<link rel="stylesheet" id="style-css" href="/Register – Nooneen Design_files/style(4).css" type="text/css" media="all">
	<link rel="stylesheet" id="the7-elementor-global-css" href="/Register – Nooneen Design_files/elementor-global.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="ecs-styles-css" href="/Register – Nooneen Design_files/ecs-style.css" type="text/css" media="all">
	<link rel="stylesheet" id="google-fonts-1-css" href="/Register – Nooneen Design_files/css(1)" type="text/css" media="all">
	<link rel="stylesheet" id="elementor-icons-shared-0-css" href="/Register – Nooneen Design_files/fontawesome.min.css" type="text/css" media="all">
	<link rel="stylesheet" id="elementor-icons-fa-solid-css" href="/Register – Nooneen Design_files/solid.min.css" type="text/css" media="all">
	<script type="text/javascript">
		/* <![CDATA[ */
		var papro_addons = {
			"url": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-admin\/admin-ajax.php",
			"particles_url": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/plugins\/premium-addons-pro\/assets\/frontend\/min-js\/particles.min.js",
			"kenburns_url": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/plugins\/premium-addons-pro\/assets\/frontend\/min-js\/cycle.min.js",
			"gradient_url": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/plugins\/premium-addons-pro\/assets\/frontend\/min-js\/premium-gradient.min.js",
			"parallax_url": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/plugins\/premium-addons-pro\/assets\/frontend\/min-js\/premium-parallax.min.js"
		};
		/* ]]> */
	</script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/jquery.js"></script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/jquery-migrate.min.js"></script>
	<script type="text/javascript">
		window.scopes_array = [];
		window.backend = 0;
		jQuery(window).on("elementor/frontend/init", function() {
			elementorFrontend.hooks.addAction("frontend/element_ready/section", function($scope, $) {
				if ("undefined" == typeof $scope) {
					return;
				}
				if ($scope.hasClass("premium-parallax-yes")) {
					window.scopes_array.push($scope);
				}
				if (elementorFrontend.isEditMode()) {
					var url = papro_addons.parallax_url;
					jQuery.cachedAssets = function(url, options) {
						// Allow user to set any option except for dataType, cache, and url.
						options = jQuery.extend(options || {}, {
							dataType: "script",
							cache: true,
							url: url
						});
						// Return the jqXHR object so we can chain callbacks.
						return jQuery.ajax(options);
					};
					jQuery.cachedAssets(url);
					window.backend = 1;
				}
			});
		});
		jQuery(document).ready(function() {
			if (jQuery.find(".premium-parallax-yes").length < 1) {
				return;
			}

			var url = papro_addons.parallax_url;

			jQuery.cachedAssets = function(url, options) {
				// Allow user to set any option except for dataType, cache, and url.
				options = jQuery.extend(options || {}, {
					dataType: "script",
					cache: true,
					url: url
				});

				// Return the jqXHR object so we can chain callbacks.
				return jQuery.ajax(options);
			};
			jQuery.cachedAssets(url);
		});
		window.scopes_array = [];
		window.backend = 0;
		jQuery(window).on("elementor/frontend/init", function() {
			elementorFrontend.hooks.addAction("frontend/element_ready/section", function($scope, $) {
				if ("undefined" == typeof $scope) {
					return;
				}
				if ($scope.hasClass("premium-particles-yes")) {
					window.scopes_array.push($scope);
				}
				if (elementorFrontend.isEditMode()) {
					var url = papro_addons.particles_url;
					jQuery.cachedAssets = function(url, options) {
						// Allow user to set any option except for dataType, cache, and url.
						options = jQuery.extend(options || {}, {
							dataType: "script",
							cache: true,
							url: url
						});
						// Return the jqXHR object so we can chain callbacks.
						return jQuery.ajax(options);
					};
					jQuery.cachedAssets(url);
					window.backend = 1;
				}
			});
		});
		jQuery(document).ready(function() {
			if (jQuery.find(".premium-particles-yes").length < 1) {

				return;
			}
			var url = papro_addons.particles_url;

			jQuery.cachedAssets = function(url, options) {
				// Allow user to set any option except for dataType, cache, and url.
				options = jQuery.extend(options || {}, {
					dataType: "script",
					cache: true,
					url: url
				});

				// Return the jqXHR object so we can chain callbacks.
				return jQuery.ajax(options);
			};
			jQuery.cachedAssets(url);
		});
		window.scopes_array = [];
		window.backend = 0;
		jQuery(window).on("elementor/frontend/init", function() {
			elementorFrontend.hooks.addAction("frontend/element_ready/section", function($scope, $) {
				if ("undefined" == typeof $scope) {
					return;
				}
				if ($scope.hasClass("premium-gradient-yes")) {
					window.scopes_array.push($scope);
				}
				if (elementorFrontend.isEditMode()) {
					var url = papro_addons.gradient_url;
					jQuery.cachedAssets = function(url, options) {
						// Allow user to set any option except for dataType, cache, and url.
						options = jQuery.extend(options || {}, {
							dataType: "script",
							cache: true,
							url: url
						});
						// Return the jqXHR object so we can chain callbacks.
						return jQuery.ajax(options);
					};
					jQuery.cachedAssets(url);
					window.backend = 1;
				}
			});
		});
		jQuery(document).ready(function() {
			if (jQuery.find(".premium-gradient-yes").length < 1) {
				return;
			}

			var url = papro_addons.gradient_url;

			jQuery.cachedAssets = function(url, options) {
				// Allow user to set any option except for dataType, cache, and url.
				options = jQuery.extend(options || {}, {
					dataType: "script",
					cache: true,
					url: url
				});

				// Return the jqXHR object so we can chain callbacks.
				return jQuery.ajax(options);
			};
			jQuery.cachedAssets(url);
		});
		window.scopes_array = [];
		window.backend = 0;
		jQuery(window).on("elementor/frontend/init", function() {
			elementorFrontend.hooks.addAction("frontend/element_ready/section", function($scope, $) {
				if ("undefined" == typeof $scope) {
					return;
				}
				if ($scope.hasClass("premium-kenburns-yes")) {
					window.scopes_array.push($scope);
				}
			});
		});
		jQuery(document).ready(function() {
			if (jQuery.find(".premium-kenburns-yes").length < 1) {
				return;
			}

			var url = papro_addons.kenburns_url;

			jQuery.cachedAssets = function(url, options) {
				// Allow user to set any option except for dataType, cache, and url.
				options = jQuery.extend(options || {}, {
					dataType: "script",
					cache: true,
					url: url
				});

				// Return the jqXHR object so we can chain callbacks.
				return jQuery.ajax(options);
			};
			jQuery.cachedAssets(url);
		});
	</script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/jquery.cookie.js"></script>
	<script type="text/javascript">
		/* <![CDATA[ */
		var wpml_cookies = {
			"wp-wpml_current_language": {
				"value": "en",
				"expires": 1,
				"path": "\/"
			}
		};
		var wpml_cookies = {
			"wp-wpml_current_language": {
				"value": "en",
				"expires": 1,
				"path": "\/"
			}
		};
		/* ]]> */
	</script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/language-cookie.js"></script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/slick.min.js"></script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/scripts.js"></script>
	<script type="text/javascript">
		/* <![CDATA[ */
		var ajax_object = {
			"ajaxurl": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-admin\/admin-ajax.php"
		};
		var plugin_dir_url = ["http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/plugins\/design_quiz\/"];
		/* ]]> */
	</script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/ajax.js"></script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/extension.min.js"></script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/woocommerce-sales-funnels.min.js"></script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/rbtools.min.js"></script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/rs6.min.js"></script>
	<script type="text/javascript">
		/* <![CDATA[ */
		var dtLocal = {
			"themeUrl": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/themes\/techreshape_v4.3",
			"passText": "To view this protected post, enter the password below:",
			"moreButtonText": {
				"loading": "Loading...",
				"loadMore": "Load more"
			},
			"postID": "629",
			"ajaxurl": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-admin\/admin-ajax.php",
			"REST": {
				"baseUrl": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-json\/the7\/v1",
				"endpoints": {
					"sendMail": "\/send-mail"
				}
			},
			"contactMessages": {
				"required": "One or more fields have an error. Please check and try again.",
				"terms": "Please accept the privacy policy.",
				"fillTheCaptchaError": "Please, fill the captcha."
			},
			"captchaSiteKey": "",
			"ajaxNonce": "6410f74edf",
			"pageData": {
				"type": "page",
				"template": "page",
				"layout": null
			},
			"themeSettings": {
				"smoothScroll": "off",
				"lazyLoading": false,
				"accentColor": {
					"mode": "solid",
					"color": "#ffe0e0"
				},
				"desktopHeader": {
					"height": 90
				},
				"ToggleCaptionEnabled": "disabled",
				"ToggleCaption": "Navigation",
				"floatingHeader": {
					"showAfter": 94,
					"showMenu": true,
					"height": 60,
					"logo": {
						"showLogo": true,
						"html": "<img class=\" preload-me\" src=\"http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/uploads\/2020\/10\/float-1.png\" srcset=\"http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/uploads\/2020\/10\/float-1.png 103w, http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/uploads\/2020\/10\/floationg-logo.png 103w\" width=\"103\" height=\"50\"   sizes=\"103px\" alt=\"Nooneen Design\" \/>",
						"url": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/"
					}
				},
				"topLine": {
					"floatingTopLine": {
						"logo": {
							"showLogo": false,
							"html": ""
						}
					}
				},
				"mobileHeader": {
					"firstSwitchPoint": 992,
					"secondSwitchPoint": 778,
					"firstSwitchPointHeight": 60,
					"secondSwitchPointHeight": 60,
					"mobileToggleCaptionEnabled": "disabled",
					"mobileToggleCaption": "Menu"
				},
				"stickyMobileHeaderFirstSwitch": {
					"logo": {
						"html": "<img class=\" preload-me\" src=\"http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/uploads\/2020\/10\/Mobile-Logo.png\" srcset=\"http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/uploads\/2020\/10\/Mobile-Logo.png 72w\" width=\"72\" height=\"35\"   sizes=\"72px\" alt=\"Nooneen Design\" \/>"
					}
				},
				"stickyMobileHeaderSecondSwitch": {
					"logo": {
						"html": "<img class=\" preload-me\" src=\"http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/uploads\/2020\/10\/Mobile-Logo.png\" srcset=\"http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-content\/uploads\/2020\/10\/Mobile-Logo.png 72w\" width=\"72\" height=\"35\"   sizes=\"72px\" alt=\"Nooneen Design\" \/>"
					}
				},
				"content": {
					"textColor": "#8b8d94",
					"headerColor": "#333333"
				},
				"sidebar": {
					"switchPoint": 992
				},
				"boxedWidth": "1280px",
				"stripes": {
					"stripe1": {
						"textColor": "#787d85",
						"headerColor": "#3b3f4a"
					},
					"stripe2": {
						"textColor": "#8b9199",
						"headerColor": "#ffffff"
					},
					"stripe3": {
						"textColor": "#ffffff",
						"headerColor": "#ffffff"
					}
				}
			},
			"wcCartFragmentHash": "e512a72c2c4de1aaeef02992ceb65a2d",
			"elementor": {
				"settings": {
					"container_width": 0
				}
			}
		};
		var dtShare = {
			"shareButtonText": {
				"facebook": "Share on Facebook",
				"twitter": "Tweet",
				"pinterest": "Pin it",
				"linkedin": "Share on Linkedin",
				"whatsapp": "Share on Whatsapp"
			},
			"overlayOpacity": "85"
		};
		/* ]]> */
	</script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/above-the-fold.min.js"></script>
	<script type="text/javascript">
		/* <![CDATA[ */
		var ecs_ajax_params = {
			"ajaxurl": "http:\/\/watrax.com\/2020\/opfor\/july\/ali\/wp-admin\/admin-ajax.php",
			"posts": "{\"page\":0,\"pagename\":\"regist\",\"error\":\"\",\"m\":\"\",\"p\":0,\"post_parent\":\"\",\"subpost\":\"\",\"subpost_id\":\"\",\"attachment\":\"\",\"attachment_id\":0,\"name\":\"regist\",\"page_id\":0,\"second\":\"\",\"minute\":\"\",\"hour\":\"\",\"day\":0,\"monthnum\":0,\"year\":0,\"w\":0,\"category_name\":\"\",\"tag\":\"\",\"cat\":\"\",\"tag_id\":\"\",\"author\":\"\",\"author_name\":\"\",\"feed\":\"\",\"tb\":\"\",\"paged\":0,\"meta_key\":\"\",\"meta_value\":\"\",\"preview\":\"\",\"s\":\"\",\"sentence\":\"\",\"title\":\"\",\"fields\":\"\",\"menu_order\":\"\",\"embed\":\"\",\"category__in\":[],\"category__not_in\":[],\"category__and\":[],\"post__in\":[],\"post__not_in\":[],\"post_name__in\":[],\"tag__in\":[],\"tag__not_in\":[],\"tag__and\":[],\"tag_slug__in\":[],\"tag_slug__and\":[],\"post_parent__in\":[],\"post_parent__not_in\":[],\"author__in\":[],\"author__not_in\":[],\"ignore_sticky_posts\":false,\"suppress_filters\":false,\"cache_results\":true,\"update_post_term_cache\":true,\"lazy_load_term_meta\":true,\"update_post_meta_cache\":true,\"post_type\":\"\",\"posts_per_page\":10,\"nopaging\":false,\"comments_per_page\":\"50\",\"no_found_rows\":false,\"order\":\"DESC\"}"
		};
		/* ]]> */
	</script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/ecs_ajax_pagination.js"></script>
	<script type="text/javascript" src="/Register – Nooneen Design_files/ecs.js"></script>
	<link rel="https://api.w.org/" href="http://watrax.com/2020/opfor/july/ali/wp-json/">
	<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://watrax.com/2020/opfor/july/ali/xmlrpc.php?rsd">
	<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://watrax.com/2020/opfor/july/ali/wp-includes/wlwmanifest.xml">
	<meta name="generator" content="WordPress 5.4.4">
	<meta name="generator" content="WooCommerce 4.3.1">
	<link rel="canonical" href="http://watrax.com/2020/opfor/july/ali/regist/">
	<link rel="shortlink" href="http://watrax.com/2020/opfor/july/ali/?p=629">
	<link rel="alternate" type="application/json+oembed" href="http://watrax.com/2020/opfor/july/ali/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fwatrax.com%2F2020%2Fopfor%2Fjuly%2Fali%2Fregist%2F">
	<link rel="alternate" type="text/xml+oembed" href="http://watrax.com/2020/opfor/july/ali/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fwatrax.com%2F2020%2Fopfor%2Fjuly%2Fali%2Fregist%2F&amp;format=xml">
	<meta name="generator" content="WPML ver:4.3.16 stt:5,1;">
	<style></style>
	<meta property="og:site_name" content="Nooneen Design">
	<meta property="og:title" content="Register">
	<meta property="og:url" content="http://watrax.com/2020/opfor/july/ali/regist/">
	<meta property="og:type" content="article">
	<noscript>
		<style>
			.woocommerce-product-gallery {
				opacity: 1 !important;
			}
		</style>
	</noscript>
	<meta name="generator" content="Powered by Slider Revolution 6.2.10 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface.">
	<link rel="icon" href="http://watrax.com/2020/opfor/july/ali/wp-content/uploads/2020/07/Favicon.png" type="image/png" sizes="16x16">
	<link rel="icon" href="http://watrax.com/2020/opfor/july/ali/wp-content/uploads/2020/07/Favicon.png" type="image/png" sizes="32x32">
	<script type="text/javascript">
		function setREVStartSize(e) {
			//window.requestAnimationFrame(function() {
			window.RSIW = window.RSIW === undefined ? window.innerWidth : window.RSIW;
			window.RSIH = window.RSIH === undefined ? window.innerHeight : window.RSIH;
			try {
				var pw = document.getElementById(e.c).parentNode.offsetWidth,
					newh;
				pw = pw === 0 || isNaN(pw) ? window.RSIW : pw;
				e.tabw = e.tabw === undefined ? 0 : parseInt(e.tabw);
				e.thumbw = e.thumbw === undefined ? 0 : parseInt(e.thumbw);
				e.tabh = e.tabh === undefined ? 0 : parseInt(e.tabh);
				e.thumbh = e.thumbh === undefined ? 0 : parseInt(e.thumbh);
				e.tabhide = e.tabhide === undefined ? 0 : parseInt(e.tabhide);
				e.thumbhide = e.thumbhide === undefined ? 0 : parseInt(e.thumbhide);
				e.mh = e.mh === undefined || e.mh == "" || e.mh === "auto" ? 0 : parseInt(e.mh, 0);
				if (e.layout === "fullscreen" || e.l === "fullscreen")
					newh = Math.max(e.mh, window.RSIH);
				else {
					e.gw = Array.isArray(e.gw) ? e.gw : [e.gw];
					for (var i in e.rl)
						if (e.gw[i] === undefined || e.gw[i] === 0) e.gw[i] = e.gw[i - 1];
					e.gh = e.el === undefined || e.el === "" || (Array.isArray(e.el) && e.el.length == 0) ? e.gh : e.el;
					e.gh = Array.isArray(e.gh) ? e.gh : [e.gh];
					for (var i in e.rl)
						if (e.gh[i] === undefined || e.gh[i] === 0) e.gh[i] = e.gh[i - 1];

					var nl = new Array(e.rl.length),
						ix = 0,
						sl;
					e.tabw = e.tabhide >= pw ? 0 : e.tabw;
					e.thumbw = e.thumbhide >= pw ? 0 : e.thumbw;
					e.tabh = e.tabhide >= pw ? 0 : e.tabh;
					e.thumbh = e.thumbhide >= pw ? 0 : e.thumbh;
					for (var i in e.rl) nl[i] = e.rl[i] < window.RSIW ? 0 : e.rl[i];
					sl = nl[0];
					for (var i in nl)
						if (sl > nl[i] && nl[i] > 0) {
							sl = nl[i];
							ix = i;
						}
					var m = pw > (e.gw[ix] + e.tabw + e.thumbw) ? 1 : (pw - (e.tabw + e.thumbw)) / (e.gw[ix]);
					newh = (e.gh[ix] * m) + (e.tabh + e.thumbh);
				}
				if (window.rs_init_css === undefined) window.rs_init_css = document.head.appendChild(document.createElement("style"));
				document.getElementById(e.c).height = newh + "px";
				window.rs_init_css.innerHTML += "#" + e.c + "_wrapper { height: " + newh + "px }";
			} catch (e) {
				console.log("Failure at Presize of Slider:" + e)
			}
			//});
		};
	</script>
	<style>
		.pswp {
			display: none;
		}
	</style>
	<script type="text/javascript">
		jQuery(document).ready(function($) {
			$('#elementor-tab-content-1891').css('display', 'none').removeClass('elementor-active');
			$('#elementor-tab-title-1891').click(function() {
				$('#elementor-tab-content-1891').css('display', 'block').addClass('elementor-active');
			})
		})
	</script>
	<style id="the7-custom-inline-css" type="text/css">
		.sub-nav .menu-item i.fa,
		.sub-nav .menu-item i.fas,
		.sub-nav .menu-item i.far,
		.sub-nav .menu-item i.fab {
			text-align: center;
			width: 1.25em;
		}
	</style>
	<style type="text/css" data-fbcssmodules="css:fb.css.basecss:fb.css.dialog css:fb.css.iframewidget css:fb.css.customer_chat_plugin_iframe">
		.fb_hidden {
			position: absolute;
			top: -10000px;
			z-index: 10001
		}

		.fb_reposition {
			overflow: hidden;
			position: relative
		}

		.fb_invisible {
			display: none
		}

		.fb_reset {
			background: none;
			border: 0;
			border-spacing: 0;
			color: #000;
			cursor: auto;
			direction: ltr;
			font-family: "lucida grande", tahoma, verdana, arial, sans-serif;
			font-size: 11px;
			font-style: normal;
			font-variant: normal;
			font-weight: normal;
			letter-spacing: normal;
			line-height: 1;
			margin: 0;
			overflow: visible;
			padding: 0;
			text-align: left;
			text-decoration: none;
			text-indent: 0;
			text-shadow: none;
			text-transform: none;
			visibility: visible;
			white-space: normal;
			word-spacing: normal
		}

		.fb_reset>div {
			overflow: hidden
		}

		@keyframes fb_transform {
			from {
				opacity: 0;
				transform: scale(.95)
			}

			to {
				opacity: 1;
				transform: scale(1)
			}
		}

		.fb_animate {
			animation: fb_transform .3s forwards
		}

		.fb_dialog {
			background: rgba(82, 82, 82, .7);
			position: absolute;
			top: -10000px;
			z-index: 10001
		}

		.fb_dialog_advanced {
			border-radius: 8px;
			padding: 10px
		}

		.fb_dialog_content {
			background: #fff;
			color: #373737
		}

		.fb_dialog_close_icon {
			background: url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 0 transparent;
			cursor: pointer;
			display: block;
			height: 15px;
			position: absolute;
			right: 18px;
			top: 17px;
			width: 15px
		}

		.fb_dialog_mobile .fb_dialog_close_icon {
			left: 5px;
			right: auto;
			top: 5px
		}

		.fb_dialog_padding {
			background-color: transparent;
			position: absolute;
			width: 1px;
			z-index: -1
		}

		.fb_dialog_close_icon:hover {
			background: url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -15px transparent
		}

		.fb_dialog_close_icon:active {
			background: url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -30px transparent
		}

		.fb_dialog_iframe {
			line-height: 0
		}

		.fb_dialog_content .dialog_title {
			background: #6d84b4;
			border: 1px solid #365899;
			color: #fff;
			font-size: 14px;
			font-weight: bold;
			margin: 0
		}

		.fb_dialog_content .dialog_title>span {
			background: url(https://static.xx.fbcdn.net/rsrc.php/v3/yd/r/Cou7n-nqK52.gif) no-repeat 5px 50%;
			float: left;
			padding: 5px 0 7px 26px
		}

		body.fb_hidden {
			height: 100%;
			left: 0;
			margin: 0;
			overflow: visible;
			position: absolute;
			top: -10000px;
			transform: none;
			width: 100%
		}

		.fb_dialog.fb_dialog_mobile.loading {
			background: url(https://static.xx.fbcdn.net/rsrc.php/v3/ya/r/3rhSv5V8j3o.gif) white no-repeat 50% 50%;
			min-height: 100%;
			min-width: 100%;
			overflow: hidden;
			position: absolute;
			top: 0;
			z-index: 10001
		}

		.fb_dialog.fb_dialog_mobile.loading.centered {
			background: none;
			height: auto;
			min-height: initial;
			min-width: initial;
			width: auto
		}

		.fb_dialog.fb_dialog_mobile.loading.centered #fb_dialog_loader_spinner {
			width: 100%
		}

		.fb_dialog.fb_dialog_mobile.loading.centered .fb_dialog_content {
			background: none
		}

		.loading.centered #fb_dialog_loader_close {
			clear: both;
			color: #fff;
			display: block;
			font-size: 18px;
			padding-top: 20px
		}

		#fb-root #fb_dialog_ipad_overlay {
			background: rgba(0, 0, 0, .4);
			bottom: 0;
			left: 0;
			min-height: 100%;
			position: absolute;
			right: 0;
			top: 0;
			width: 100%;
			z-index: 10000
		}

		#fb-root #fb_dialog_ipad_overlay.hidden {
			display: none
		}

		.fb_dialog.fb_dialog_mobile.loading iframe {
			visibility: hidden
		}

		.fb_dialog_mobile .fb_dialog_iframe {
			position: sticky;
			top: 0
		}

		.fb_dialog_content .dialog_header {
			background: linear-gradient(from(#738aba), to(#2c4987));
			border-bottom: 1px solid;
			border-color: #043b87;
			box-shadow: white 0 1px 1px -1px inset;
			color: #fff;
			font: bold 14px Helvetica, sans-serif;
			text-overflow: ellipsis;
			text-shadow: rgba(0, 30, 84, .296875) 0 -1px 0;
			vertical-align: middle;
			white-space: nowrap
		}

		.fb_dialog_content .dialog_header table {
			height: 43px;
			width: 100%
		}

		.fb_dialog_content .dialog_header td.header_left {
			font-size: 12px;
			padding-left: 5px;
			vertical-align: middle;
			width: 60px
		}

		.fb_dialog_content .dialog_header td.header_right {
			font-size: 12px;
			padding-right: 5px;
			vertical-align: middle;
			width: 60px
		}

		.fb_dialog_content .touchable_button {
			background: linear-gradient(from(#4267B2), to(#2a4887));
			background-clip: padding-box;
			border: 1px solid #29487d;
			border-radius: 3px;
			display: inline-block;
			line-height: 18px;
			margin-top: 3px;
			max-width: 85px;
			padding: 4px 12px;
			position: relative
		}

		.fb_dialog_content .dialog_header .touchable_button input {
			background: none;
			border: none;
			color: #fff;
			font: bold 12px Helvetica, sans-serif;
			margin: 2px -12px;
			padding: 2px 6px 3px 6px;
			text-shadow: rgba(0, 30, 84, .296875) 0 -1px 0
		}

		.fb_dialog_content .dialog_header .header_center {
			color: #fff;
			font-size: 16px;
			font-weight: bold;
			line-height: 18px;
			text-align: center;
			vertical-align: middle
		}

		.fb_dialog_content .dialog_content {
			background: url(https://static.xx.fbcdn.net/rsrc.php/v3/y9/r/jKEcVPZFk-2.gif) no-repeat 50% 50%;
			border: 1px solid #4a4a4a;
			border-bottom: 0;
			border-top: 0;
			height: 150px
		}

		.fb_dialog_content .dialog_footer {
			background: #f5f6f7;
			border: 1px solid #4a4a4a;
			border-top-color: #ccc;
			height: 40px
		}

		#fb_dialog_loader_close {
			float: left
		}

		.fb_dialog.fb_dialog_mobile .fb_dialog_close_icon {
			visibility: hidden
		}

		#fb_dialog_loader_spinner {
			animation: rotateSpinner 1.2s linear infinite;
			background-color: transparent;
			background-image: url(https://static.xx.fbcdn.net/rsrc.php/v3/yD/r/t-wz8gw1xG1.png);
			background-position: 50% 50%;
			background-repeat: no-repeat;
			height: 24px;
			width: 24px
		}

		@keyframes rotateSpinner {
			0% {
				transform: rotate(0deg)
			}

			100% {
				transform: rotate(360deg)
			}
		}

		.fb_iframe_widget {
			display: inline-block;
			position: relative
		}

		.fb_iframe_widget span {
			display: inline-block;
			position: relative;
			text-align: justify
		}

		.fb_iframe_widget iframe {
			position: absolute
		}

		.fb_iframe_widget_fluid_desktop,
		.fb_iframe_widget_fluid_desktop span,
		.fb_iframe_widget_fluid_desktop iframe {
			max-width: 100%
		}

		.fb_iframe_widget_fluid_desktop iframe {
			min-width: 220px;
			position: relative
		}

		.fb_iframe_widget_lift {
			z-index: 1
		}

		.fb_iframe_widget_fluid {
			display: inline
		}

		.fb_iframe_widget_fluid span {
			width: 100%
		}

		.fb_mpn_mobile_landing_page_slide_in {
			animation-duration: 200ms;
			animation-name: fb_mpn_landing_page_slide_in;
			transition-timing-function: ease-in
		}

		.fb_mpn_mobile_landing_page_slide_out {
			animation-duration: 200ms;
			animation-name: fb_mpn_landing_page_slide_out;
			transition-timing-function: ease-in
		}

		.fb_mpn_mobile_landing_page_slide_out_from_left {
			animation-duration: 200ms;
			animation-name: fb_mpn_landing_page_slide_out_from_left;
			transition-timing-function: ease-in
		}

		.fb_mpn_mobile_landing_page_slide_up {
			animation-duration: 500ms;
			animation-name: fb_mpn_landing_page_slide_up;
			transition-timing-function: ease-in
		}

		.fb_mpn_mobile_bounce_in {
			animation-duration: 300ms;
			animation-name: fb_mpn_bounce_in;
			transition-timing-function: ease-in
		}

		.fb_mpn_mobile_bounce_out {
			animation-duration: 300ms;
			animation-name: fb_mpn_bounce_out;
			transition-timing-function: ease-in
		}

		.fb_customer_chat_bounce_in_v2 {
			animation-duration: 300ms;
			animation-name: fb_bounce_in_v2;
			transition-timing-function: ease-in
		}

		.fb_customer_chat_bounce_in_from_left {
			animation-duration: 300ms;
			animation-name: fb_bounce_in_from_left;
			transition-timing-function: ease-in
		}

		.fb_customer_chat_bounce_out_v2 {
			animation-duration: 300ms;
			animation-name: fb_bounce_out_v2;
			transition-timing-function: ease-in
		}

		.fb_customer_chat_bounce_out_from_left {
			animation-duration: 300ms;
			animation-name: fb_bounce_out_from_left;
			transition-timing-function: ease-in
		}

		.fb_customer_chat_bounce_in_v2_mobile_chat_started {
			animation-duration: 300ms;
			animation-name: fb_bounce_in_v2_mobile_chat_started;
			transition-timing-function: ease-in
		}

		.fb_customer_chat_bounce_out_v2_mobile_chat_started {
			animation-duration: 300ms;
			animation-name: fb_bounce_out_v2_mobile_chat_started;
			transition-timing-function: ease-in
		}

		.fb_customer_chat_bubble_pop_in {
			animation-duration: 250ms;
			animation-name: fb_customer_chat_bubble_bounce_in_animation
		}

		.fb_customer_chat_bubble_animated_no_badge {
			box-shadow: 0 3px 12px rgba(0, 0, 0, .15);
			transition: box-shadow 150ms linear
		}

		.fb_customer_chat_bubble_animated_no_badge:hover {
			box-shadow: 0 5px 24px rgba(0, 0, 0, .3)
		}

		.fb_customer_chat_bubble_animated_with_badge {
			box-shadow: -5px 4px 14px rgba(0, 0, 0, .15);
			transition: box-shadow 150ms linear
		}

		.fb_customer_chat_bubble_animated_with_badge:hover {
			box-shadow: -5px 8px 24px rgba(0, 0, 0, .2)
		}

		.fb_invisible_flow {
			display: inherit;
			height: 0;
			overflow-x: hidden;
			width: 0
		}

		.fb_mobile_overlay_active {
			background-color: #fff;
			height: 100%;
			overflow: hidden;
			position: fixed;
			visibility: hidden;
			width: 100%
		}

		.fb_new_ui_mobile_overlay_active {
			overflow: hidden
		}

		@keyframes fb_mpn_landing_page_slide_in {
			0% {
				border-radius: 50%;
				margin: 0 24px;
				width: 60px
			}

			40% {
				border-radius: 18px
			}

			100% {
				margin: 0 12px;
				width: 100% - 24px
			}
		}

		@keyframes fb_mpn_landing_page_slide_in_from_left {
			0% {
				border-radius: 50%;
				left: 12px;
				margin: 0 24px;
				width: 60px
			}

			40% {
				border-radius: 18px
			}

			100% {
				left: 12px;
				margin: 0 12px;
				width: 100% - 24px
			}
		}

		@keyframes fb_mpn_landing_page_slide_out {
			0% {
				margin: 0 12px;
				width: 100% - 24px
			}

			60% {
				border-radius: 18px
			}

			100% {
				border-radius: 50%;
				margin: 0 24px;
				width: 60px
			}
		}

		@keyframes fb_mpn_landing_page_slide_out_from_left {
			0% {
				left: 12px;
				width: 100% - 24px
			}

			60% {
				border-radius: 18px
			}

			100% {
				border-radius: 50%;
				left: 12px;
				width: 60px
			}
		}

		@keyframes fb_mpn_landing_page_slide_up {
			0% {
				bottom: 0;
				opacity: 0
			}

			100% {
				bottom: 24px;
				opacity: 1
			}
		}

		@keyframes fb_mpn_bounce_in {
			0% {
				opacity: .5;
				top: 100%
			}

			100% {
				opacity: 1;
				top: 0
			}
		}

		@keyframes fb_mpn_bounce_out {
			0% {
				opacity: 1;
				top: 0
			}

			100% {
				opacity: .5;
				top: 100%
			}
		}

		@keyframes fb_bounce_in_v2 {
			0% {
				opacity: 0;
				transform: scale(0, 0);
				transform-origin: bottom right
			}

			50% {
				transform: scale(1.03, 1.03);
				transform-origin: bottom right
			}

			100% {
				opacity: 1;
				transform: scale(1, 1);
				transform-origin: bottom right
			}
		}

		@keyframes fb_bounce_in_from_left {
			0% {
				opacity: 0;
				transform: scale(0, 0);
				transform-origin: bottom left
			}

			50% {
				transform: scale(1.03, 1.03);
				transform-origin: bottom left
			}

			100% {
				opacity: 1;
				transform: scale(1, 1);
				transform-origin: bottom left
			}
		}

		@keyframes fb_bounce_in_v2_mobile_chat_started {
			0% {
				opacity: 0;
				top: 20px
			}

			100% {
				opacity: 1;
				top: 0
			}
		}

		@keyframes fb_bounce_out_v2 {
			0% {
				opacity: 1;
				transform: scale(1, 1);
				transform-origin: bottom right
			}

			100% {
				opacity: 0;
				transform: scale(0, 0);
				transform-origin: bottom right
			}
		}

		@keyframes fb_bounce_out_from_left {
			0% {
				opacity: 1;
				transform: scale(1, 1);
				transform-origin: bottom left
			}

			100% {
				opacity: 0;
				transform: scale(0, 0);
				transform-origin: bottom left
			}
		}

		@keyframes fb_bounce_out_v2_mobile_chat_started {
			0% {
				opacity: 1;
				top: 0
			}

			100% {
				opacity: 0;
				top: 20px
			}
		}

		@keyframes fb_customer_chat_bubble_bounce_in_animation {
			0% {
				bottom: 6pt;
				opacity: 0;
				transform: scale(0, 0);
				transform-origin: center
			}

			70% {
				bottom: 18pt;
				opacity: 1;
				transform: scale(1.2, 1.2)
			}

			100% {
				transform: scale(1, 1)
			}
		}
	</style>
  <!-- <link rel="stylesheet" href="/css/bootstrap.min.css" /> -->

</head>

    <body>
    @include('Parts.navbar')


<div style="padding-top:80">
            @yield('content')
    @include('Parts.footer')
</div>
    </body>
</html>
